################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (11.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/lvgl/examples/assets/emoji/img_emoji_F617.c 

OBJS += \
./Core/lvgl/examples/assets/emoji/img_emoji_F617.o 

C_DEPS += \
./Core/lvgl/examples/assets/emoji/img_emoji_F617.d 


# Each subdirectory must supply rules for building sources it contributes
Core/lvgl/examples/assets/emoji/%.o Core/lvgl/examples/assets/emoji/%.su Core/lvgl/examples/assets/emoji/%.cyclo: ../Core/lvgl/examples/assets/emoji/%.c Core/lvgl/examples/assets/emoji/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m0 -std=gnu11 -DUSE_HAL_DRIVER -DSTM32F072xB -c -I../Core/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F0xx/Include -I../Drivers/CMSIS/Include -Os -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-Core-2f-lvgl-2f-examples-2f-assets-2f-emoji

clean-Core-2f-lvgl-2f-examples-2f-assets-2f-emoji:
	-$(RM) ./Core/lvgl/examples/assets/emoji/img_emoji_F617.cyclo ./Core/lvgl/examples/assets/emoji/img_emoji_F617.d ./Core/lvgl/examples/assets/emoji/img_emoji_F617.o ./Core/lvgl/examples/assets/emoji/img_emoji_F617.su

.PHONY: clean-Core-2f-lvgl-2f-examples-2f-assets-2f-emoji

