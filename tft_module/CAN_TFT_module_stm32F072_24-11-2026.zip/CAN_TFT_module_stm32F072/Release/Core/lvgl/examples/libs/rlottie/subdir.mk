################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (11.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/lvgl/examples/libs/rlottie/lv_example_rlottie_1.c \
../Core/lvgl/examples/libs/rlottie/lv_example_rlottie_2.c \
../Core/lvgl/examples/libs/rlottie/lv_example_rlottie_approve.c 

OBJS += \
./Core/lvgl/examples/libs/rlottie/lv_example_rlottie_1.o \
./Core/lvgl/examples/libs/rlottie/lv_example_rlottie_2.o \
./Core/lvgl/examples/libs/rlottie/lv_example_rlottie_approve.o 

C_DEPS += \
./Core/lvgl/examples/libs/rlottie/lv_example_rlottie_1.d \
./Core/lvgl/examples/libs/rlottie/lv_example_rlottie_2.d \
./Core/lvgl/examples/libs/rlottie/lv_example_rlottie_approve.d 


# Each subdirectory must supply rules for building sources it contributes
Core/lvgl/examples/libs/rlottie/%.o Core/lvgl/examples/libs/rlottie/%.su Core/lvgl/examples/libs/rlottie/%.cyclo: ../Core/lvgl/examples/libs/rlottie/%.c Core/lvgl/examples/libs/rlottie/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m0 -std=gnu11 -DUSE_HAL_DRIVER -DSTM32F072xB -c -I../Core/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F0xx/Include -I../Drivers/CMSIS/Include -Os -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-Core-2f-lvgl-2f-examples-2f-libs-2f-rlottie

clean-Core-2f-lvgl-2f-examples-2f-libs-2f-rlottie:
	-$(RM) ./Core/lvgl/examples/libs/rlottie/lv_example_rlottie_1.cyclo ./Core/lvgl/examples/libs/rlottie/lv_example_rlottie_1.d ./Core/lvgl/examples/libs/rlottie/lv_example_rlottie_1.o ./Core/lvgl/examples/libs/rlottie/lv_example_rlottie_1.su ./Core/lvgl/examples/libs/rlottie/lv_example_rlottie_2.cyclo ./Core/lvgl/examples/libs/rlottie/lv_example_rlottie_2.d ./Core/lvgl/examples/libs/rlottie/lv_example_rlottie_2.o ./Core/lvgl/examples/libs/rlottie/lv_example_rlottie_2.su ./Core/lvgl/examples/libs/rlottie/lv_example_rlottie_approve.cyclo ./Core/lvgl/examples/libs/rlottie/lv_example_rlottie_approve.d ./Core/lvgl/examples/libs/rlottie/lv_example_rlottie_approve.o ./Core/lvgl/examples/libs/rlottie/lv_example_rlottie_approve.su

.PHONY: clean-Core-2f-lvgl-2f-examples-2f-libs-2f-rlottie

