################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (11.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/lvgl/examples/libs/gif/img_bulb_gif.c \
../Core/lvgl/examples/libs/gif/lv_example_gif_1.c 

OBJS += \
./Core/lvgl/examples/libs/gif/img_bulb_gif.o \
./Core/lvgl/examples/libs/gif/lv_example_gif_1.o 

C_DEPS += \
./Core/lvgl/examples/libs/gif/img_bulb_gif.d \
./Core/lvgl/examples/libs/gif/lv_example_gif_1.d 


# Each subdirectory must supply rules for building sources it contributes
Core/lvgl/examples/libs/gif/%.o Core/lvgl/examples/libs/gif/%.su Core/lvgl/examples/libs/gif/%.cyclo: ../Core/lvgl/examples/libs/gif/%.c Core/lvgl/examples/libs/gif/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m0 -std=gnu11 -DUSE_HAL_DRIVER -DSTM32F072xB -c -I../Core/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F0xx/Include -I../Drivers/CMSIS/Include -Os -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-Core-2f-lvgl-2f-examples-2f-libs-2f-gif

clean-Core-2f-lvgl-2f-examples-2f-libs-2f-gif:
	-$(RM) ./Core/lvgl/examples/libs/gif/img_bulb_gif.cyclo ./Core/lvgl/examples/libs/gif/img_bulb_gif.d ./Core/lvgl/examples/libs/gif/img_bulb_gif.o ./Core/lvgl/examples/libs/gif/img_bulb_gif.su ./Core/lvgl/examples/libs/gif/lv_example_gif_1.cyclo ./Core/lvgl/examples/libs/gif/lv_example_gif_1.d ./Core/lvgl/examples/libs/gif/lv_example_gif_1.o ./Core/lvgl/examples/libs/gif/lv_example_gif_1.su

.PHONY: clean-Core-2f-lvgl-2f-examples-2f-libs-2f-gif

