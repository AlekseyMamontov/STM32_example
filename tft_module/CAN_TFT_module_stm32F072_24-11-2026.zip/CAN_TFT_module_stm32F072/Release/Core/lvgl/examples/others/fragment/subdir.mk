################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (11.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/lvgl/examples/others/fragment/lv_example_fragment_1.c \
../Core/lvgl/examples/others/fragment/lv_example_fragment_2.c 

OBJS += \
./Core/lvgl/examples/others/fragment/lv_example_fragment_1.o \
./Core/lvgl/examples/others/fragment/lv_example_fragment_2.o 

C_DEPS += \
./Core/lvgl/examples/others/fragment/lv_example_fragment_1.d \
./Core/lvgl/examples/others/fragment/lv_example_fragment_2.d 


# Each subdirectory must supply rules for building sources it contributes
Core/lvgl/examples/others/fragment/%.o Core/lvgl/examples/others/fragment/%.su Core/lvgl/examples/others/fragment/%.cyclo: ../Core/lvgl/examples/others/fragment/%.c Core/lvgl/examples/others/fragment/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m0 -std=gnu11 -DUSE_HAL_DRIVER -DSTM32F072xB -c -I../Core/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F0xx/Include -I../Drivers/CMSIS/Include -Os -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-Core-2f-lvgl-2f-examples-2f-others-2f-fragment

clean-Core-2f-lvgl-2f-examples-2f-others-2f-fragment:
	-$(RM) ./Core/lvgl/examples/others/fragment/lv_example_fragment_1.cyclo ./Core/lvgl/examples/others/fragment/lv_example_fragment_1.d ./Core/lvgl/examples/others/fragment/lv_example_fragment_1.o ./Core/lvgl/examples/others/fragment/lv_example_fragment_1.su ./Core/lvgl/examples/others/fragment/lv_example_fragment_2.cyclo ./Core/lvgl/examples/others/fragment/lv_example_fragment_2.d ./Core/lvgl/examples/others/fragment/lv_example_fragment_2.o ./Core/lvgl/examples/others/fragment/lv_example_fragment_2.su

.PHONY: clean-Core-2f-lvgl-2f-examples-2f-others-2f-fragment

