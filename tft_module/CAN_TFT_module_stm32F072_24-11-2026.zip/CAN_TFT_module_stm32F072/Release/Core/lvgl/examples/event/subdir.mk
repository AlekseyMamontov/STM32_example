################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (11.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/lvgl/examples/event/lv_example_event_1.c \
../Core/lvgl/examples/event/lv_example_event_2.c \
../Core/lvgl/examples/event/lv_example_event_3.c \
../Core/lvgl/examples/event/lv_example_event_4.c 

OBJS += \
./Core/lvgl/examples/event/lv_example_event_1.o \
./Core/lvgl/examples/event/lv_example_event_2.o \
./Core/lvgl/examples/event/lv_example_event_3.o \
./Core/lvgl/examples/event/lv_example_event_4.o 

C_DEPS += \
./Core/lvgl/examples/event/lv_example_event_1.d \
./Core/lvgl/examples/event/lv_example_event_2.d \
./Core/lvgl/examples/event/lv_example_event_3.d \
./Core/lvgl/examples/event/lv_example_event_4.d 


# Each subdirectory must supply rules for building sources it contributes
Core/lvgl/examples/event/%.o Core/lvgl/examples/event/%.su Core/lvgl/examples/event/%.cyclo: ../Core/lvgl/examples/event/%.c Core/lvgl/examples/event/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m0 -std=gnu11 -DUSE_HAL_DRIVER -DSTM32F072xB -c -I../Core/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F0xx/Include -I../Drivers/CMSIS/Include -Os -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-Core-2f-lvgl-2f-examples-2f-event

clean-Core-2f-lvgl-2f-examples-2f-event:
	-$(RM) ./Core/lvgl/examples/event/lv_example_event_1.cyclo ./Core/lvgl/examples/event/lv_example_event_1.d ./Core/lvgl/examples/event/lv_example_event_1.o ./Core/lvgl/examples/event/lv_example_event_1.su ./Core/lvgl/examples/event/lv_example_event_2.cyclo ./Core/lvgl/examples/event/lv_example_event_2.d ./Core/lvgl/examples/event/lv_example_event_2.o ./Core/lvgl/examples/event/lv_example_event_2.su ./Core/lvgl/examples/event/lv_example_event_3.cyclo ./Core/lvgl/examples/event/lv_example_event_3.d ./Core/lvgl/examples/event/lv_example_event_3.o ./Core/lvgl/examples/event/lv_example_event_3.su ./Core/lvgl/examples/event/lv_example_event_4.cyclo ./Core/lvgl/examples/event/lv_example_event_4.d ./Core/lvgl/examples/event/lv_example_event_4.o ./Core/lvgl/examples/event/lv_example_event_4.su

.PHONY: clean-Core-2f-lvgl-2f-examples-2f-event

