################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (11.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/lvgl/demos/transform/assets/img_transform_avatar_15.c 

OBJS += \
./Core/lvgl/demos/transform/assets/img_transform_avatar_15.o 

C_DEPS += \
./Core/lvgl/demos/transform/assets/img_transform_avatar_15.d 


# Each subdirectory must supply rules for building sources it contributes
Core/lvgl/demos/transform/assets/%.o Core/lvgl/demos/transform/assets/%.su Core/lvgl/demos/transform/assets/%.cyclo: ../Core/lvgl/demos/transform/assets/%.c Core/lvgl/demos/transform/assets/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m0 -std=gnu11 -DUSE_HAL_DRIVER -DSTM32F072xB -c -I../Core/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F0xx/Include -I../Drivers/CMSIS/Include -Os -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-Core-2f-lvgl-2f-demos-2f-transform-2f-assets

clean-Core-2f-lvgl-2f-demos-2f-transform-2f-assets:
	-$(RM) ./Core/lvgl/demos/transform/assets/img_transform_avatar_15.cyclo ./Core/lvgl/demos/transform/assets/img_transform_avatar_15.d ./Core/lvgl/demos/transform/assets/img_transform_avatar_15.o ./Core/lvgl/demos/transform/assets/img_transform_avatar_15.su

.PHONY: clean-Core-2f-lvgl-2f-demos-2f-transform-2f-assets

