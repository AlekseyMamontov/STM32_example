################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (11.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/lvgl/demos/lv_demos.c 

OBJS += \
./Core/lvgl/demos/lv_demos.o 

C_DEPS += \
./Core/lvgl/demos/lv_demos.d 


# Each subdirectory must supply rules for building sources it contributes
Core/lvgl/demos/%.o Core/lvgl/demos/%.su Core/lvgl/demos/%.cyclo: ../Core/lvgl/demos/%.c Core/lvgl/demos/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m0 -std=gnu11 -DUSE_HAL_DRIVER -DSTM32F072xB -c -I../Core/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F0xx/Include -I../Drivers/CMSIS/Include -Os -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-Core-2f-lvgl-2f-demos

clean-Core-2f-lvgl-2f-demos:
	-$(RM) ./Core/lvgl/demos/lv_demos.cyclo ./Core/lvgl/demos/lv_demos.d ./Core/lvgl/demos/lv_demos.o ./Core/lvgl/demos/lv_demos.su

.PHONY: clean-Core-2f-lvgl-2f-demos

