################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (11.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/lvgl/demos/benchmark/assets/img_benchmark_cogwheel_alpha256.c \
../Core/lvgl/demos/benchmark/assets/img_benchmark_cogwheel_argb.c \
../Core/lvgl/demos/benchmark/assets/img_benchmark_cogwheel_indexed16.c \
../Core/lvgl/demos/benchmark/assets/img_benchmark_cogwheel_rgb.c \
../Core/lvgl/demos/benchmark/assets/lv_font_benchmark_montserrat_12_compr_az.c.c \
../Core/lvgl/demos/benchmark/assets/lv_font_benchmark_montserrat_16_compr_az.c.c \
../Core/lvgl/demos/benchmark/assets/lv_font_benchmark_montserrat_28_compr_az.c.c 

OBJS += \
./Core/lvgl/demos/benchmark/assets/img_benchmark_cogwheel_alpha256.o \
./Core/lvgl/demos/benchmark/assets/img_benchmark_cogwheel_argb.o \
./Core/lvgl/demos/benchmark/assets/img_benchmark_cogwheel_indexed16.o \
./Core/lvgl/demos/benchmark/assets/img_benchmark_cogwheel_rgb.o \
./Core/lvgl/demos/benchmark/assets/lv_font_benchmark_montserrat_12_compr_az.c.o \
./Core/lvgl/demos/benchmark/assets/lv_font_benchmark_montserrat_16_compr_az.c.o \
./Core/lvgl/demos/benchmark/assets/lv_font_benchmark_montserrat_28_compr_az.c.o 

C_DEPS += \
./Core/lvgl/demos/benchmark/assets/img_benchmark_cogwheel_alpha256.d \
./Core/lvgl/demos/benchmark/assets/img_benchmark_cogwheel_argb.d \
./Core/lvgl/demos/benchmark/assets/img_benchmark_cogwheel_indexed16.d \
./Core/lvgl/demos/benchmark/assets/img_benchmark_cogwheel_rgb.d \
./Core/lvgl/demos/benchmark/assets/lv_font_benchmark_montserrat_12_compr_az.c.d \
./Core/lvgl/demos/benchmark/assets/lv_font_benchmark_montserrat_16_compr_az.c.d \
./Core/lvgl/demos/benchmark/assets/lv_font_benchmark_montserrat_28_compr_az.c.d 


# Each subdirectory must supply rules for building sources it contributes
Core/lvgl/demos/benchmark/assets/%.o Core/lvgl/demos/benchmark/assets/%.su Core/lvgl/demos/benchmark/assets/%.cyclo: ../Core/lvgl/demos/benchmark/assets/%.c Core/lvgl/demos/benchmark/assets/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m0 -std=gnu11 -DUSE_HAL_DRIVER -DSTM32F072xB -c -I../Core/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F0xx/Include -I../Drivers/CMSIS/Include -Os -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-Core-2f-lvgl-2f-demos-2f-benchmark-2f-assets

clean-Core-2f-lvgl-2f-demos-2f-benchmark-2f-assets:
	-$(RM) ./Core/lvgl/demos/benchmark/assets/img_benchmark_cogwheel_alpha256.cyclo ./Core/lvgl/demos/benchmark/assets/img_benchmark_cogwheel_alpha256.d ./Core/lvgl/demos/benchmark/assets/img_benchmark_cogwheel_alpha256.o ./Core/lvgl/demos/benchmark/assets/img_benchmark_cogwheel_alpha256.su ./Core/lvgl/demos/benchmark/assets/img_benchmark_cogwheel_argb.cyclo ./Core/lvgl/demos/benchmark/assets/img_benchmark_cogwheel_argb.d ./Core/lvgl/demos/benchmark/assets/img_benchmark_cogwheel_argb.o ./Core/lvgl/demos/benchmark/assets/img_benchmark_cogwheel_argb.su ./Core/lvgl/demos/benchmark/assets/img_benchmark_cogwheel_indexed16.cyclo ./Core/lvgl/demos/benchmark/assets/img_benchmark_cogwheel_indexed16.d ./Core/lvgl/demos/benchmark/assets/img_benchmark_cogwheel_indexed16.o ./Core/lvgl/demos/benchmark/assets/img_benchmark_cogwheel_indexed16.su ./Core/lvgl/demos/benchmark/assets/img_benchmark_cogwheel_rgb.cyclo ./Core/lvgl/demos/benchmark/assets/img_benchmark_cogwheel_rgb.d ./Core/lvgl/demos/benchmark/assets/img_benchmark_cogwheel_rgb.o ./Core/lvgl/demos/benchmark/assets/img_benchmark_cogwheel_rgb.su ./Core/lvgl/demos/benchmark/assets/lv_font_benchmark_montserrat_12_compr_az.c.cyclo ./Core/lvgl/demos/benchmark/assets/lv_font_benchmark_montserrat_12_compr_az.c.d ./Core/lvgl/demos/benchmark/assets/lv_font_benchmark_montserrat_12_compr_az.c.o ./Core/lvgl/demos/benchmark/assets/lv_font_benchmark_montserrat_12_compr_az.c.su ./Core/lvgl/demos/benchmark/assets/lv_font_benchmark_montserrat_16_compr_az.c.cyclo ./Core/lvgl/demos/benchmark/assets/lv_font_benchmark_montserrat_16_compr_az.c.d ./Core/lvgl/demos/benchmark/assets/lv_font_benchmark_montserrat_16_compr_az.c.o ./Core/lvgl/demos/benchmark/assets/lv_font_benchmark_montserrat_16_compr_az.c.su ./Core/lvgl/demos/benchmark/assets/lv_font_benchmark_montserrat_28_compr_az.c.cyclo ./Core/lvgl/demos/benchmark/assets/lv_font_benchmark_montserrat_28_compr_az.c.d ./Core/lvgl/demos/benchmark/assets/lv_font_benchmark_montserrat_28_compr_az.c.o ./Core/lvgl/demos/benchmark/assets/lv_font_benchmark_montserrat_28_compr_az.c.su

.PHONY: clean-Core-2f-lvgl-2f-demos-2f-benchmark-2f-assets

