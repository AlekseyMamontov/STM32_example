################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (11.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/lvgl/demos/multilang/assets/emojis/img_emoji_artist_palette.c \
../Core/lvgl/demos/multilang/assets/emojis/img_emoji_books.c \
../Core/lvgl/demos/multilang/assets/emojis/img_emoji_camera_with_flash.c \
../Core/lvgl/demos/multilang/assets/emojis/img_emoji_cat_face.c \
../Core/lvgl/demos/multilang/assets/emojis/img_emoji_deciduous_tree.c \
../Core/lvgl/demos/multilang/assets/emojis/img_emoji_dog_face.c \
../Core/lvgl/demos/multilang/assets/emojis/img_emoji_earth_globe_europe_africa.c \
../Core/lvgl/demos/multilang/assets/emojis/img_emoji_flexed_biceps.c \
../Core/lvgl/demos/multilang/assets/emojis/img_emoji_movie_camera.c \
../Core/lvgl/demos/multilang/assets/emojis/img_emoji_red_heart.c \
../Core/lvgl/demos/multilang/assets/emojis/img_emoji_rocket.c \
../Core/lvgl/demos/multilang/assets/emojis/img_emoji_soccer_ball.c 

OBJS += \
./Core/lvgl/demos/multilang/assets/emojis/img_emoji_artist_palette.o \
./Core/lvgl/demos/multilang/assets/emojis/img_emoji_books.o \
./Core/lvgl/demos/multilang/assets/emojis/img_emoji_camera_with_flash.o \
./Core/lvgl/demos/multilang/assets/emojis/img_emoji_cat_face.o \
./Core/lvgl/demos/multilang/assets/emojis/img_emoji_deciduous_tree.o \
./Core/lvgl/demos/multilang/assets/emojis/img_emoji_dog_face.o \
./Core/lvgl/demos/multilang/assets/emojis/img_emoji_earth_globe_europe_africa.o \
./Core/lvgl/demos/multilang/assets/emojis/img_emoji_flexed_biceps.o \
./Core/lvgl/demos/multilang/assets/emojis/img_emoji_movie_camera.o \
./Core/lvgl/demos/multilang/assets/emojis/img_emoji_red_heart.o \
./Core/lvgl/demos/multilang/assets/emojis/img_emoji_rocket.o \
./Core/lvgl/demos/multilang/assets/emojis/img_emoji_soccer_ball.o 

C_DEPS += \
./Core/lvgl/demos/multilang/assets/emojis/img_emoji_artist_palette.d \
./Core/lvgl/demos/multilang/assets/emojis/img_emoji_books.d \
./Core/lvgl/demos/multilang/assets/emojis/img_emoji_camera_with_flash.d \
./Core/lvgl/demos/multilang/assets/emojis/img_emoji_cat_face.d \
./Core/lvgl/demos/multilang/assets/emojis/img_emoji_deciduous_tree.d \
./Core/lvgl/demos/multilang/assets/emojis/img_emoji_dog_face.d \
./Core/lvgl/demos/multilang/assets/emojis/img_emoji_earth_globe_europe_africa.d \
./Core/lvgl/demos/multilang/assets/emojis/img_emoji_flexed_biceps.d \
./Core/lvgl/demos/multilang/assets/emojis/img_emoji_movie_camera.d \
./Core/lvgl/demos/multilang/assets/emojis/img_emoji_red_heart.d \
./Core/lvgl/demos/multilang/assets/emojis/img_emoji_rocket.d \
./Core/lvgl/demos/multilang/assets/emojis/img_emoji_soccer_ball.d 


# Each subdirectory must supply rules for building sources it contributes
Core/lvgl/demos/multilang/assets/emojis/%.o Core/lvgl/demos/multilang/assets/emojis/%.su Core/lvgl/demos/multilang/assets/emojis/%.cyclo: ../Core/lvgl/demos/multilang/assets/emojis/%.c Core/lvgl/demos/multilang/assets/emojis/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m0 -std=gnu11 -DUSE_HAL_DRIVER -DSTM32F072xB -c -I../Core/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F0xx/Include -I../Drivers/CMSIS/Include -Os -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-Core-2f-lvgl-2f-demos-2f-multilang-2f-assets-2f-emojis

clean-Core-2f-lvgl-2f-demos-2f-multilang-2f-assets-2f-emojis:
	-$(RM) ./Core/lvgl/demos/multilang/assets/emojis/img_emoji_artist_palette.cyclo ./Core/lvgl/demos/multilang/assets/emojis/img_emoji_artist_palette.d ./Core/lvgl/demos/multilang/assets/emojis/img_emoji_artist_palette.o ./Core/lvgl/demos/multilang/assets/emojis/img_emoji_artist_palette.su ./Core/lvgl/demos/multilang/assets/emojis/img_emoji_books.cyclo ./Core/lvgl/demos/multilang/assets/emojis/img_emoji_books.d ./Core/lvgl/demos/multilang/assets/emojis/img_emoji_books.o ./Core/lvgl/demos/multilang/assets/emojis/img_emoji_books.su ./Core/lvgl/demos/multilang/assets/emojis/img_emoji_camera_with_flash.cyclo ./Core/lvgl/demos/multilang/assets/emojis/img_emoji_camera_with_flash.d ./Core/lvgl/demos/multilang/assets/emojis/img_emoji_camera_with_flash.o ./Core/lvgl/demos/multilang/assets/emojis/img_emoji_camera_with_flash.su ./Core/lvgl/demos/multilang/assets/emojis/img_emoji_cat_face.cyclo ./Core/lvgl/demos/multilang/assets/emojis/img_emoji_cat_face.d ./Core/lvgl/demos/multilang/assets/emojis/img_emoji_cat_face.o ./Core/lvgl/demos/multilang/assets/emojis/img_emoji_cat_face.su ./Core/lvgl/demos/multilang/assets/emojis/img_emoji_deciduous_tree.cyclo ./Core/lvgl/demos/multilang/assets/emojis/img_emoji_deciduous_tree.d ./Core/lvgl/demos/multilang/assets/emojis/img_emoji_deciduous_tree.o ./Core/lvgl/demos/multilang/assets/emojis/img_emoji_deciduous_tree.su ./Core/lvgl/demos/multilang/assets/emojis/img_emoji_dog_face.cyclo ./Core/lvgl/demos/multilang/assets/emojis/img_emoji_dog_face.d ./Core/lvgl/demos/multilang/assets/emojis/img_emoji_dog_face.o ./Core/lvgl/demos/multilang/assets/emojis/img_emoji_dog_face.su ./Core/lvgl/demos/multilang/assets/emojis/img_emoji_earth_globe_europe_africa.cyclo ./Core/lvgl/demos/multilang/assets/emojis/img_emoji_earth_globe_europe_africa.d ./Core/lvgl/demos/multilang/assets/emojis/img_emoji_earth_globe_europe_africa.o ./Core/lvgl/demos/multilang/assets/emojis/img_emoji_earth_globe_europe_africa.su ./Core/lvgl/demos/multilang/assets/emojis/img_emoji_flexed_biceps.cyclo ./Core/lvgl/demos/multilang/assets/emojis/img_emoji_flexed_biceps.d ./Core/lvgl/demos/multilang/assets/emojis/img_emoji_flexed_biceps.o ./Core/lvgl/demos/multilang/assets/emojis/img_emoji_flexed_biceps.su ./Core/lvgl/demos/multilang/assets/emojis/img_emoji_movie_camera.cyclo ./Core/lvgl/demos/multilang/assets/emojis/img_emoji_movie_camera.d ./Core/lvgl/demos/multilang/assets/emojis/img_emoji_movie_camera.o ./Core/lvgl/demos/multilang/assets/emojis/img_emoji_movie_camera.su ./Core/lvgl/demos/multilang/assets/emojis/img_emoji_red_heart.cyclo ./Core/lvgl/demos/multilang/assets/emojis/img_emoji_red_heart.d ./Core/lvgl/demos/multilang/assets/emojis/img_emoji_red_heart.o ./Core/lvgl/demos/multilang/assets/emojis/img_emoji_red_heart.su ./Core/lvgl/demos/multilang/assets/emojis/img_emoji_rocket.cyclo ./Core/lvgl/demos/multilang/assets/emojis/img_emoji_rocket.d ./Core/lvgl/demos/multilang/assets/emojis/img_emoji_rocket.o ./Core/lvgl/demos/multilang/assets/emojis/img_emoji_rocket.su ./Core/lvgl/demos/multilang/assets/emojis/img_emoji_soccer_ball.cyclo ./Core/lvgl/demos/multilang/assets/emojis/img_emoji_soccer_ball.d ./Core/lvgl/demos/multilang/assets/emojis/img_emoji_soccer_ball.o ./Core/lvgl/demos/multilang/assets/emojis/img_emoji_soccer_ball.su

.PHONY: clean-Core-2f-lvgl-2f-demos-2f-multilang-2f-assets-2f-emojis

