################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (11.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/lvgl/demos/scroll/lv_demo_scroll.c 

OBJS += \
./Core/lvgl/demos/scroll/lv_demo_scroll.o 

C_DEPS += \
./Core/lvgl/demos/scroll/lv_demo_scroll.d 


# Each subdirectory must supply rules for building sources it contributes
Core/lvgl/demos/scroll/%.o Core/lvgl/demos/scroll/%.su Core/lvgl/demos/scroll/%.cyclo: ../Core/lvgl/demos/scroll/%.c Core/lvgl/demos/scroll/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m0 -std=gnu11 -DUSE_HAL_DRIVER -DSTM32F072xB -c -I../Core/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F0xx/Include -I../Drivers/CMSIS/Include -Os -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-Core-2f-lvgl-2f-demos-2f-scroll

clean-Core-2f-lvgl-2f-demos-2f-scroll:
	-$(RM) ./Core/lvgl/demos/scroll/lv_demo_scroll.cyclo ./Core/lvgl/demos/scroll/lv_demo_scroll.d ./Core/lvgl/demos/scroll/lv_demo_scroll.o ./Core/lvgl/demos/scroll/lv_demo_scroll.su

.PHONY: clean-Core-2f-lvgl-2f-demos-2f-scroll

