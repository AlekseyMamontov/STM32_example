################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (11.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/lvgl/src/libs/freetype/lv_freetype.c \
../Core/lvgl/src/libs/freetype/lv_freetype_image.c \
../Core/lvgl/src/libs/freetype/lv_freetype_outline.c \
../Core/lvgl/src/libs/freetype/lv_freetype_sbit.c \
../Core/lvgl/src/libs/freetype/lv_ftsystem.c 

OBJS += \
./Core/lvgl/src/libs/freetype/lv_freetype.o \
./Core/lvgl/src/libs/freetype/lv_freetype_image.o \
./Core/lvgl/src/libs/freetype/lv_freetype_outline.o \
./Core/lvgl/src/libs/freetype/lv_freetype_sbit.o \
./Core/lvgl/src/libs/freetype/lv_ftsystem.o 

C_DEPS += \
./Core/lvgl/src/libs/freetype/lv_freetype.d \
./Core/lvgl/src/libs/freetype/lv_freetype_image.d \
./Core/lvgl/src/libs/freetype/lv_freetype_outline.d \
./Core/lvgl/src/libs/freetype/lv_freetype_sbit.d \
./Core/lvgl/src/libs/freetype/lv_ftsystem.d 


# Each subdirectory must supply rules for building sources it contributes
Core/lvgl/src/libs/freetype/%.o Core/lvgl/src/libs/freetype/%.su Core/lvgl/src/libs/freetype/%.cyclo: ../Core/lvgl/src/libs/freetype/%.c Core/lvgl/src/libs/freetype/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m0 -std=gnu11 -DUSE_HAL_DRIVER -DSTM32F072xB -c -I../Core/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F0xx/Include -I../Drivers/CMSIS/Include -Os -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-Core-2f-lvgl-2f-src-2f-libs-2f-freetype

clean-Core-2f-lvgl-2f-src-2f-libs-2f-freetype:
	-$(RM) ./Core/lvgl/src/libs/freetype/lv_freetype.cyclo ./Core/lvgl/src/libs/freetype/lv_freetype.d ./Core/lvgl/src/libs/freetype/lv_freetype.o ./Core/lvgl/src/libs/freetype/lv_freetype.su ./Core/lvgl/src/libs/freetype/lv_freetype_image.cyclo ./Core/lvgl/src/libs/freetype/lv_freetype_image.d ./Core/lvgl/src/libs/freetype/lv_freetype_image.o ./Core/lvgl/src/libs/freetype/lv_freetype_image.su ./Core/lvgl/src/libs/freetype/lv_freetype_outline.cyclo ./Core/lvgl/src/libs/freetype/lv_freetype_outline.d ./Core/lvgl/src/libs/freetype/lv_freetype_outline.o ./Core/lvgl/src/libs/freetype/lv_freetype_outline.su ./Core/lvgl/src/libs/freetype/lv_freetype_sbit.cyclo ./Core/lvgl/src/libs/freetype/lv_freetype_sbit.d ./Core/lvgl/src/libs/freetype/lv_freetype_sbit.o ./Core/lvgl/src/libs/freetype/lv_freetype_sbit.su ./Core/lvgl/src/libs/freetype/lv_ftsystem.cyclo ./Core/lvgl/src/libs/freetype/lv_ftsystem.d ./Core/lvgl/src/libs/freetype/lv_ftsystem.o ./Core/lvgl/src/libs/freetype/lv_ftsystem.su

.PHONY: clean-Core-2f-lvgl-2f-src-2f-libs-2f-freetype

