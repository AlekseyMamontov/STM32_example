################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (11.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/lvgl/src/libs/lodepng/lodepng.c \
../Core/lvgl/src/libs/lodepng/lv_lodepng.c 

OBJS += \
./Core/lvgl/src/libs/lodepng/lodepng.o \
./Core/lvgl/src/libs/lodepng/lv_lodepng.o 

C_DEPS += \
./Core/lvgl/src/libs/lodepng/lodepng.d \
./Core/lvgl/src/libs/lodepng/lv_lodepng.d 


# Each subdirectory must supply rules for building sources it contributes
Core/lvgl/src/libs/lodepng/%.o Core/lvgl/src/libs/lodepng/%.su Core/lvgl/src/libs/lodepng/%.cyclo: ../Core/lvgl/src/libs/lodepng/%.c Core/lvgl/src/libs/lodepng/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m0 -std=gnu11 -DUSE_HAL_DRIVER -DSTM32F072xB -c -I../Core/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F0xx/Include -I../Drivers/CMSIS/Include -Os -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-Core-2f-lvgl-2f-src-2f-libs-2f-lodepng

clean-Core-2f-lvgl-2f-src-2f-libs-2f-lodepng:
	-$(RM) ./Core/lvgl/src/libs/lodepng/lodepng.cyclo ./Core/lvgl/src/libs/lodepng/lodepng.d ./Core/lvgl/src/libs/lodepng/lodepng.o ./Core/lvgl/src/libs/lodepng/lodepng.su ./Core/lvgl/src/libs/lodepng/lv_lodepng.cyclo ./Core/lvgl/src/libs/lodepng/lv_lodepng.d ./Core/lvgl/src/libs/lodepng/lv_lodepng.o ./Core/lvgl/src/libs/lodepng/lv_lodepng.su

.PHONY: clean-Core-2f-lvgl-2f-src-2f-libs-2f-lodepng

