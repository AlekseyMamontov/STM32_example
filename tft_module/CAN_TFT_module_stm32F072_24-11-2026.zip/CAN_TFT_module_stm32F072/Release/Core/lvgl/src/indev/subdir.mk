################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (11.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/lvgl/src/indev/lv_indev.c \
../Core/lvgl/src/indev/lv_indev_scroll.c 

OBJS += \
./Core/lvgl/src/indev/lv_indev.o \
./Core/lvgl/src/indev/lv_indev_scroll.o 

C_DEPS += \
./Core/lvgl/src/indev/lv_indev.d \
./Core/lvgl/src/indev/lv_indev_scroll.d 


# Each subdirectory must supply rules for building sources it contributes
Core/lvgl/src/indev/%.o Core/lvgl/src/indev/%.su Core/lvgl/src/indev/%.cyclo: ../Core/lvgl/src/indev/%.c Core/lvgl/src/indev/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m0 -std=gnu11 -DUSE_HAL_DRIVER -DSTM32F072xB -c -I../Core/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F0xx/Include -I../Drivers/CMSIS/Include -Os -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-Core-2f-lvgl-2f-src-2f-indev

clean-Core-2f-lvgl-2f-src-2f-indev:
	-$(RM) ./Core/lvgl/src/indev/lv_indev.cyclo ./Core/lvgl/src/indev/lv_indev.d ./Core/lvgl/src/indev/lv_indev.o ./Core/lvgl/src/indev/lv_indev.su ./Core/lvgl/src/indev/lv_indev_scroll.cyclo ./Core/lvgl/src/indev/lv_indev_scroll.d ./Core/lvgl/src/indev/lv_indev_scroll.o ./Core/lvgl/src/indev/lv_indev_scroll.su

.PHONY: clean-Core-2f-lvgl-2f-src-2f-indev

