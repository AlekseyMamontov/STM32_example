################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (11.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/lvgl/src/draw/sw/blend/lv_draw_sw_blend.c \
../Core/lvgl/src/draw/sw/blend/lv_draw_sw_blend_to_argb8888.c \
../Core/lvgl/src/draw/sw/blend/lv_draw_sw_blend_to_rgb565.c \
../Core/lvgl/src/draw/sw/blend/lv_draw_sw_blend_to_rgb888.c 

OBJS += \
./Core/lvgl/src/draw/sw/blend/lv_draw_sw_blend.o \
./Core/lvgl/src/draw/sw/blend/lv_draw_sw_blend_to_argb8888.o \
./Core/lvgl/src/draw/sw/blend/lv_draw_sw_blend_to_rgb565.o \
./Core/lvgl/src/draw/sw/blend/lv_draw_sw_blend_to_rgb888.o 

C_DEPS += \
./Core/lvgl/src/draw/sw/blend/lv_draw_sw_blend.d \
./Core/lvgl/src/draw/sw/blend/lv_draw_sw_blend_to_argb8888.d \
./Core/lvgl/src/draw/sw/blend/lv_draw_sw_blend_to_rgb565.d \
./Core/lvgl/src/draw/sw/blend/lv_draw_sw_blend_to_rgb888.d 


# Each subdirectory must supply rules for building sources it contributes
Core/lvgl/src/draw/sw/blend/%.o Core/lvgl/src/draw/sw/blend/%.su Core/lvgl/src/draw/sw/blend/%.cyclo: ../Core/lvgl/src/draw/sw/blend/%.c Core/lvgl/src/draw/sw/blend/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m0 -std=gnu11 -DUSE_HAL_DRIVER -DSTM32F072xB -c -I../Core/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F0xx/Include -I../Drivers/CMSIS/Include -Os -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-Core-2f-lvgl-2f-src-2f-draw-2f-sw-2f-blend

clean-Core-2f-lvgl-2f-src-2f-draw-2f-sw-2f-blend:
	-$(RM) ./Core/lvgl/src/draw/sw/blend/lv_draw_sw_blend.cyclo ./Core/lvgl/src/draw/sw/blend/lv_draw_sw_blend.d ./Core/lvgl/src/draw/sw/blend/lv_draw_sw_blend.o ./Core/lvgl/src/draw/sw/blend/lv_draw_sw_blend.su ./Core/lvgl/src/draw/sw/blend/lv_draw_sw_blend_to_argb8888.cyclo ./Core/lvgl/src/draw/sw/blend/lv_draw_sw_blend_to_argb8888.d ./Core/lvgl/src/draw/sw/blend/lv_draw_sw_blend_to_argb8888.o ./Core/lvgl/src/draw/sw/blend/lv_draw_sw_blend_to_argb8888.su ./Core/lvgl/src/draw/sw/blend/lv_draw_sw_blend_to_rgb565.cyclo ./Core/lvgl/src/draw/sw/blend/lv_draw_sw_blend_to_rgb565.d ./Core/lvgl/src/draw/sw/blend/lv_draw_sw_blend_to_rgb565.o ./Core/lvgl/src/draw/sw/blend/lv_draw_sw_blend_to_rgb565.su ./Core/lvgl/src/draw/sw/blend/lv_draw_sw_blend_to_rgb888.cyclo ./Core/lvgl/src/draw/sw/blend/lv_draw_sw_blend_to_rgb888.d ./Core/lvgl/src/draw/sw/blend/lv_draw_sw_blend_to_rgb888.o ./Core/lvgl/src/draw/sw/blend/lv_draw_sw_blend_to_rgb888.su

.PHONY: clean-Core-2f-lvgl-2f-src-2f-draw-2f-sw-2f-blend

