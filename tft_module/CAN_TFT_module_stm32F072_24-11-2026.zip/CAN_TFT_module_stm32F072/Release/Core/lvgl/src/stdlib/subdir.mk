################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (11.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/lvgl/src/stdlib/lv_mem.c 

OBJS += \
./Core/lvgl/src/stdlib/lv_mem.o 

C_DEPS += \
./Core/lvgl/src/stdlib/lv_mem.d 


# Each subdirectory must supply rules for building sources it contributes
Core/lvgl/src/stdlib/%.o Core/lvgl/src/stdlib/%.su Core/lvgl/src/stdlib/%.cyclo: ../Core/lvgl/src/stdlib/%.c Core/lvgl/src/stdlib/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m0 -std=gnu11 -DUSE_HAL_DRIVER -DSTM32F072xB -c -I../Core/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F0xx/Include -I../Drivers/CMSIS/Include -Os -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-Core-2f-lvgl-2f-src-2f-stdlib

clean-Core-2f-lvgl-2f-src-2f-stdlib:
	-$(RM) ./Core/lvgl/src/stdlib/lv_mem.cyclo ./Core/lvgl/src/stdlib/lv_mem.d ./Core/lvgl/src/stdlib/lv_mem.o ./Core/lvgl/src/stdlib/lv_mem.su

.PHONY: clean-Core-2f-lvgl-2f-src-2f-stdlib

