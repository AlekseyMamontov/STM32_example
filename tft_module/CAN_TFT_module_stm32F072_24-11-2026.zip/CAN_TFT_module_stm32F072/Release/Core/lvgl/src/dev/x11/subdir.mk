################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (11.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/lvgl/src/dev/x11/lv_x11_display.c \
../Core/lvgl/src/dev/x11/lv_x11_input.c 

OBJS += \
./Core/lvgl/src/dev/x11/lv_x11_display.o \
./Core/lvgl/src/dev/x11/lv_x11_input.o 

C_DEPS += \
./Core/lvgl/src/dev/x11/lv_x11_display.d \
./Core/lvgl/src/dev/x11/lv_x11_input.d 


# Each subdirectory must supply rules for building sources it contributes
Core/lvgl/src/dev/x11/%.o Core/lvgl/src/dev/x11/%.su Core/lvgl/src/dev/x11/%.cyclo: ../Core/lvgl/src/dev/x11/%.c Core/lvgl/src/dev/x11/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m0 -std=gnu11 -DUSE_HAL_DRIVER -DSTM32F072xB -c -I../Core/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F0xx/Include -I../Drivers/CMSIS/Include -Os -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-Core-2f-lvgl-2f-src-2f-dev-2f-x11

clean-Core-2f-lvgl-2f-src-2f-dev-2f-x11:
	-$(RM) ./Core/lvgl/src/dev/x11/lv_x11_display.cyclo ./Core/lvgl/src/dev/x11/lv_x11_display.d ./Core/lvgl/src/dev/x11/lv_x11_display.o ./Core/lvgl/src/dev/x11/lv_x11_display.su ./Core/lvgl/src/dev/x11/lv_x11_input.cyclo ./Core/lvgl/src/dev/x11/lv_x11_input.d ./Core/lvgl/src/dev/x11/lv_x11_input.o ./Core/lvgl/src/dev/x11/lv_x11_input.su

.PHONY: clean-Core-2f-lvgl-2f-src-2f-dev-2f-x11

