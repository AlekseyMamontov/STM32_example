################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (11.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/lvgl/src/dev/nuttx/lv_nuttx_entry.c \
../Core/lvgl/src/dev/nuttx/lv_nuttx_fbdev.c \
../Core/lvgl/src/dev/nuttx/lv_nuttx_lcd.c \
../Core/lvgl/src/dev/nuttx/lv_nuttx_libuv.c \
../Core/lvgl/src/dev/nuttx/lv_nuttx_touchscreen.c 

OBJS += \
./Core/lvgl/src/dev/nuttx/lv_nuttx_entry.o \
./Core/lvgl/src/dev/nuttx/lv_nuttx_fbdev.o \
./Core/lvgl/src/dev/nuttx/lv_nuttx_lcd.o \
./Core/lvgl/src/dev/nuttx/lv_nuttx_libuv.o \
./Core/lvgl/src/dev/nuttx/lv_nuttx_touchscreen.o 

C_DEPS += \
./Core/lvgl/src/dev/nuttx/lv_nuttx_entry.d \
./Core/lvgl/src/dev/nuttx/lv_nuttx_fbdev.d \
./Core/lvgl/src/dev/nuttx/lv_nuttx_lcd.d \
./Core/lvgl/src/dev/nuttx/lv_nuttx_libuv.d \
./Core/lvgl/src/dev/nuttx/lv_nuttx_touchscreen.d 


# Each subdirectory must supply rules for building sources it contributes
Core/lvgl/src/dev/nuttx/%.o Core/lvgl/src/dev/nuttx/%.su Core/lvgl/src/dev/nuttx/%.cyclo: ../Core/lvgl/src/dev/nuttx/%.c Core/lvgl/src/dev/nuttx/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m0 -std=gnu11 -DUSE_HAL_DRIVER -DSTM32F072xB -c -I../Core/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F0xx/Include -I../Drivers/CMSIS/Include -Os -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-Core-2f-lvgl-2f-src-2f-dev-2f-nuttx

clean-Core-2f-lvgl-2f-src-2f-dev-2f-nuttx:
	-$(RM) ./Core/lvgl/src/dev/nuttx/lv_nuttx_entry.cyclo ./Core/lvgl/src/dev/nuttx/lv_nuttx_entry.d ./Core/lvgl/src/dev/nuttx/lv_nuttx_entry.o ./Core/lvgl/src/dev/nuttx/lv_nuttx_entry.su ./Core/lvgl/src/dev/nuttx/lv_nuttx_fbdev.cyclo ./Core/lvgl/src/dev/nuttx/lv_nuttx_fbdev.d ./Core/lvgl/src/dev/nuttx/lv_nuttx_fbdev.o ./Core/lvgl/src/dev/nuttx/lv_nuttx_fbdev.su ./Core/lvgl/src/dev/nuttx/lv_nuttx_lcd.cyclo ./Core/lvgl/src/dev/nuttx/lv_nuttx_lcd.d ./Core/lvgl/src/dev/nuttx/lv_nuttx_lcd.o ./Core/lvgl/src/dev/nuttx/lv_nuttx_lcd.su ./Core/lvgl/src/dev/nuttx/lv_nuttx_libuv.cyclo ./Core/lvgl/src/dev/nuttx/lv_nuttx_libuv.d ./Core/lvgl/src/dev/nuttx/lv_nuttx_libuv.o ./Core/lvgl/src/dev/nuttx/lv_nuttx_libuv.su ./Core/lvgl/src/dev/nuttx/lv_nuttx_touchscreen.cyclo ./Core/lvgl/src/dev/nuttx/lv_nuttx_touchscreen.d ./Core/lvgl/src/dev/nuttx/lv_nuttx_touchscreen.o ./Core/lvgl/src/dev/nuttx/lv_nuttx_touchscreen.su

.PHONY: clean-Core-2f-lvgl-2f-src-2f-dev-2f-nuttx

