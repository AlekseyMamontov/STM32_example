################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (11.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/lvgl/src/dev/sdl/lv_sdl_keyboard.c \
../Core/lvgl/src/dev/sdl/lv_sdl_mouse.c \
../Core/lvgl/src/dev/sdl/lv_sdl_mousewheel.c \
../Core/lvgl/src/dev/sdl/lv_sdl_window.c 

OBJS += \
./Core/lvgl/src/dev/sdl/lv_sdl_keyboard.o \
./Core/lvgl/src/dev/sdl/lv_sdl_mouse.o \
./Core/lvgl/src/dev/sdl/lv_sdl_mousewheel.o \
./Core/lvgl/src/dev/sdl/lv_sdl_window.o 

C_DEPS += \
./Core/lvgl/src/dev/sdl/lv_sdl_keyboard.d \
./Core/lvgl/src/dev/sdl/lv_sdl_mouse.d \
./Core/lvgl/src/dev/sdl/lv_sdl_mousewheel.d \
./Core/lvgl/src/dev/sdl/lv_sdl_window.d 


# Each subdirectory must supply rules for building sources it contributes
Core/lvgl/src/dev/sdl/%.o Core/lvgl/src/dev/sdl/%.su Core/lvgl/src/dev/sdl/%.cyclo: ../Core/lvgl/src/dev/sdl/%.c Core/lvgl/src/dev/sdl/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m0 -std=gnu11 -DUSE_HAL_DRIVER -DSTM32F072xB -c -I../Core/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F0xx/Include -I../Drivers/CMSIS/Include -Os -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-Core-2f-lvgl-2f-src-2f-dev-2f-sdl

clean-Core-2f-lvgl-2f-src-2f-dev-2f-sdl:
	-$(RM) ./Core/lvgl/src/dev/sdl/lv_sdl_keyboard.cyclo ./Core/lvgl/src/dev/sdl/lv_sdl_keyboard.d ./Core/lvgl/src/dev/sdl/lv_sdl_keyboard.o ./Core/lvgl/src/dev/sdl/lv_sdl_keyboard.su ./Core/lvgl/src/dev/sdl/lv_sdl_mouse.cyclo ./Core/lvgl/src/dev/sdl/lv_sdl_mouse.d ./Core/lvgl/src/dev/sdl/lv_sdl_mouse.o ./Core/lvgl/src/dev/sdl/lv_sdl_mouse.su ./Core/lvgl/src/dev/sdl/lv_sdl_mousewheel.cyclo ./Core/lvgl/src/dev/sdl/lv_sdl_mousewheel.d ./Core/lvgl/src/dev/sdl/lv_sdl_mousewheel.o ./Core/lvgl/src/dev/sdl/lv_sdl_mousewheel.su ./Core/lvgl/src/dev/sdl/lv_sdl_window.cyclo ./Core/lvgl/src/dev/sdl/lv_sdl_window.d ./Core/lvgl/src/dev/sdl/lv_sdl_window.o ./Core/lvgl/src/dev/sdl/lv_sdl_window.su

.PHONY: clean-Core-2f-lvgl-2f-src-2f-dev-2f-sdl

