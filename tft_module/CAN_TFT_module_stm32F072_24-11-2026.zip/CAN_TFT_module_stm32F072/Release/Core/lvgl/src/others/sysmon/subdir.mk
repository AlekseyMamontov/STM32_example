################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (11.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/lvgl/src/others/sysmon/lv_sysmon.c 

OBJS += \
./Core/lvgl/src/others/sysmon/lv_sysmon.o 

C_DEPS += \
./Core/lvgl/src/others/sysmon/lv_sysmon.d 


# Each subdirectory must supply rules for building sources it contributes
Core/lvgl/src/others/sysmon/%.o Core/lvgl/src/others/sysmon/%.su Core/lvgl/src/others/sysmon/%.cyclo: ../Core/lvgl/src/others/sysmon/%.c Core/lvgl/src/others/sysmon/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m0 -std=gnu11 -DUSE_HAL_DRIVER -DSTM32F072xB -c -I../Core/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F0xx/Include -I../Drivers/CMSIS/Include -Os -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-Core-2f-lvgl-2f-src-2f-others-2f-sysmon

clean-Core-2f-lvgl-2f-src-2f-others-2f-sysmon:
	-$(RM) ./Core/lvgl/src/others/sysmon/lv_sysmon.cyclo ./Core/lvgl/src/others/sysmon/lv_sysmon.d ./Core/lvgl/src/others/sysmon/lv_sysmon.o ./Core/lvgl/src/others/sysmon/lv_sysmon.su

.PHONY: clean-Core-2f-lvgl-2f-src-2f-others-2f-sysmon

