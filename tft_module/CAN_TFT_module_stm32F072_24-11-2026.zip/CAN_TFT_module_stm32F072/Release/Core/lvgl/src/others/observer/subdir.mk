################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (11.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/lvgl/src/others/observer/lv_observer.c 

OBJS += \
./Core/lvgl/src/others/observer/lv_observer.o 

C_DEPS += \
./Core/lvgl/src/others/observer/lv_observer.d 


# Each subdirectory must supply rules for building sources it contributes
Core/lvgl/src/others/observer/%.o Core/lvgl/src/others/observer/%.su Core/lvgl/src/others/observer/%.cyclo: ../Core/lvgl/src/others/observer/%.c Core/lvgl/src/others/observer/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m0 -std=gnu11 -DUSE_HAL_DRIVER -DSTM32F072xB -c -I../Core/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F0xx/Include -I../Drivers/CMSIS/Include -Os -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-Core-2f-lvgl-2f-src-2f-others-2f-observer

clean-Core-2f-lvgl-2f-src-2f-others-2f-observer:
	-$(RM) ./Core/lvgl/src/others/observer/lv_observer.cyclo ./Core/lvgl/src/others/observer/lv_observer.d ./Core/lvgl/src/others/observer/lv_observer.o ./Core/lvgl/src/others/observer/lv_observer.su

.PHONY: clean-Core-2f-lvgl-2f-src-2f-others-2f-observer

