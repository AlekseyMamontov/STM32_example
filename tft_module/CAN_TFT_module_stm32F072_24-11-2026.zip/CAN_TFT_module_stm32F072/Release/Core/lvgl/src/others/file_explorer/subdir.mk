################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (11.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/lvgl/src/others/file_explorer/lv_file_explorer.c 

OBJS += \
./Core/lvgl/src/others/file_explorer/lv_file_explorer.o 

C_DEPS += \
./Core/lvgl/src/others/file_explorer/lv_file_explorer.d 


# Each subdirectory must supply rules for building sources it contributes
Core/lvgl/src/others/file_explorer/%.o Core/lvgl/src/others/file_explorer/%.su Core/lvgl/src/others/file_explorer/%.cyclo: ../Core/lvgl/src/others/file_explorer/%.c Core/lvgl/src/others/file_explorer/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m0 -std=gnu11 -DUSE_HAL_DRIVER -DSTM32F072xB -c -I../Core/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F0xx/Include -I../Drivers/CMSIS/Include -Os -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-Core-2f-lvgl-2f-src-2f-others-2f-file_explorer

clean-Core-2f-lvgl-2f-src-2f-others-2f-file_explorer:
	-$(RM) ./Core/lvgl/src/others/file_explorer/lv_file_explorer.cyclo ./Core/lvgl/src/others/file_explorer/lv_file_explorer.d ./Core/lvgl/src/others/file_explorer/lv_file_explorer.o ./Core/lvgl/src/others/file_explorer/lv_file_explorer.su

.PHONY: clean-Core-2f-lvgl-2f-src-2f-others-2f-file_explorer

