################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (11.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/lvgl/tests/src/test_cases/_test_template.c \
../Core/lvgl/tests/src/test_cases/test_anim.c \
../Core/lvgl/tests/src/test_cases/test_anim_timeline.c \
../Core/lvgl/tests/src/test_cases/test_array.c \
../Core/lvgl/tests/src/test_cases/test_bindings.c \
../Core/lvgl/tests/src/test_cases/test_config.c \
../Core/lvgl/tests/src/test_cases/test_demo_stress.c \
../Core/lvgl/tests/src/test_cases/test_demo_widgets.c \
../Core/lvgl/tests/src/test_cases/test_event.c \
../Core/lvgl/tests/src/test_cases/test_font_loader.c \
../Core/lvgl/tests/src/test_cases/test_fs.c \
../Core/lvgl/tests/src/test_cases/test_grid.c \
../Core/lvgl/tests/src/test_cases/test_group.c \
../Core/lvgl/tests/src/test_cases/test_margin_align.c \
../Core/lvgl/tests/src/test_cases/test_margin_flex.c \
../Core/lvgl/tests/src/test_cases/test_margin_grid.c \
../Core/lvgl/tests/src/test_cases/test_math.c \
../Core/lvgl/tests/src/test_cases/test_mem.c \
../Core/lvgl/tests/src/test_cases/test_observer.c \
../Core/lvgl/tests/src/test_cases/test_screen_load.c \
../Core/lvgl/tests/src/test_cases/test_snapshot.c \
../Core/lvgl/tests/src/test_cases/test_style.c \
../Core/lvgl/tests/src/test_cases/test_txt.c 

OBJS += \
./Core/lvgl/tests/src/test_cases/_test_template.o \
./Core/lvgl/tests/src/test_cases/test_anim.o \
./Core/lvgl/tests/src/test_cases/test_anim_timeline.o \
./Core/lvgl/tests/src/test_cases/test_array.o \
./Core/lvgl/tests/src/test_cases/test_bindings.o \
./Core/lvgl/tests/src/test_cases/test_config.o \
./Core/lvgl/tests/src/test_cases/test_demo_stress.o \
./Core/lvgl/tests/src/test_cases/test_demo_widgets.o \
./Core/lvgl/tests/src/test_cases/test_event.o \
./Core/lvgl/tests/src/test_cases/test_font_loader.o \
./Core/lvgl/tests/src/test_cases/test_fs.o \
./Core/lvgl/tests/src/test_cases/test_grid.o \
./Core/lvgl/tests/src/test_cases/test_group.o \
./Core/lvgl/tests/src/test_cases/test_margin_align.o \
./Core/lvgl/tests/src/test_cases/test_margin_flex.o \
./Core/lvgl/tests/src/test_cases/test_margin_grid.o \
./Core/lvgl/tests/src/test_cases/test_math.o \
./Core/lvgl/tests/src/test_cases/test_mem.o \
./Core/lvgl/tests/src/test_cases/test_observer.o \
./Core/lvgl/tests/src/test_cases/test_screen_load.o \
./Core/lvgl/tests/src/test_cases/test_snapshot.o \
./Core/lvgl/tests/src/test_cases/test_style.o \
./Core/lvgl/tests/src/test_cases/test_txt.o 

C_DEPS += \
./Core/lvgl/tests/src/test_cases/_test_template.d \
./Core/lvgl/tests/src/test_cases/test_anim.d \
./Core/lvgl/tests/src/test_cases/test_anim_timeline.d \
./Core/lvgl/tests/src/test_cases/test_array.d \
./Core/lvgl/tests/src/test_cases/test_bindings.d \
./Core/lvgl/tests/src/test_cases/test_config.d \
./Core/lvgl/tests/src/test_cases/test_demo_stress.d \
./Core/lvgl/tests/src/test_cases/test_demo_widgets.d \
./Core/lvgl/tests/src/test_cases/test_event.d \
./Core/lvgl/tests/src/test_cases/test_font_loader.d \
./Core/lvgl/tests/src/test_cases/test_fs.d \
./Core/lvgl/tests/src/test_cases/test_grid.d \
./Core/lvgl/tests/src/test_cases/test_group.d \
./Core/lvgl/tests/src/test_cases/test_margin_align.d \
./Core/lvgl/tests/src/test_cases/test_margin_flex.d \
./Core/lvgl/tests/src/test_cases/test_margin_grid.d \
./Core/lvgl/tests/src/test_cases/test_math.d \
./Core/lvgl/tests/src/test_cases/test_mem.d \
./Core/lvgl/tests/src/test_cases/test_observer.d \
./Core/lvgl/tests/src/test_cases/test_screen_load.d \
./Core/lvgl/tests/src/test_cases/test_snapshot.d \
./Core/lvgl/tests/src/test_cases/test_style.d \
./Core/lvgl/tests/src/test_cases/test_txt.d 


# Each subdirectory must supply rules for building sources it contributes
Core/lvgl/tests/src/test_cases/%.o Core/lvgl/tests/src/test_cases/%.su Core/lvgl/tests/src/test_cases/%.cyclo: ../Core/lvgl/tests/src/test_cases/%.c Core/lvgl/tests/src/test_cases/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m0 -std=gnu11 -DUSE_HAL_DRIVER -DSTM32F072xB -c -I../Core/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F0xx/Include -I../Drivers/CMSIS/Include -Os -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-Core-2f-lvgl-2f-tests-2f-src-2f-test_cases

clean-Core-2f-lvgl-2f-tests-2f-src-2f-test_cases:
	-$(RM) ./Core/lvgl/tests/src/test_cases/_test_template.cyclo ./Core/lvgl/tests/src/test_cases/_test_template.d ./Core/lvgl/tests/src/test_cases/_test_template.o ./Core/lvgl/tests/src/test_cases/_test_template.su ./Core/lvgl/tests/src/test_cases/test_anim.cyclo ./Core/lvgl/tests/src/test_cases/test_anim.d ./Core/lvgl/tests/src/test_cases/test_anim.o ./Core/lvgl/tests/src/test_cases/test_anim.su ./Core/lvgl/tests/src/test_cases/test_anim_timeline.cyclo ./Core/lvgl/tests/src/test_cases/test_anim_timeline.d ./Core/lvgl/tests/src/test_cases/test_anim_timeline.o ./Core/lvgl/tests/src/test_cases/test_anim_timeline.su ./Core/lvgl/tests/src/test_cases/test_array.cyclo ./Core/lvgl/tests/src/test_cases/test_array.d ./Core/lvgl/tests/src/test_cases/test_array.o ./Core/lvgl/tests/src/test_cases/test_array.su ./Core/lvgl/tests/src/test_cases/test_bindings.cyclo ./Core/lvgl/tests/src/test_cases/test_bindings.d ./Core/lvgl/tests/src/test_cases/test_bindings.o ./Core/lvgl/tests/src/test_cases/test_bindings.su ./Core/lvgl/tests/src/test_cases/test_config.cyclo ./Core/lvgl/tests/src/test_cases/test_config.d ./Core/lvgl/tests/src/test_cases/test_config.o ./Core/lvgl/tests/src/test_cases/test_config.su ./Core/lvgl/tests/src/test_cases/test_demo_stress.cyclo ./Core/lvgl/tests/src/test_cases/test_demo_stress.d ./Core/lvgl/tests/src/test_cases/test_demo_stress.o ./Core/lvgl/tests/src/test_cases/test_demo_stress.su ./Core/lvgl/tests/src/test_cases/test_demo_widgets.cyclo ./Core/lvgl/tests/src/test_cases/test_demo_widgets.d ./Core/lvgl/tests/src/test_cases/test_demo_widgets.o ./Core/lvgl/tests/src/test_cases/test_demo_widgets.su ./Core/lvgl/tests/src/test_cases/test_event.cyclo ./Core/lvgl/tests/src/test_cases/test_event.d ./Core/lvgl/tests/src/test_cases/test_event.o ./Core/lvgl/tests/src/test_cases/test_event.su ./Core/lvgl/tests/src/test_cases/test_font_loader.cyclo ./Core/lvgl/tests/src/test_cases/test_font_loader.d ./Core/lvgl/tests/src/test_cases/test_font_loader.o ./Core/lvgl/tests/src/test_cases/test_font_loader.su ./Core/lvgl/tests/src/test_cases/test_fs.cyclo ./Core/lvgl/tests/src/test_cases/test_fs.d ./Core/lvgl/tests/src/test_cases/test_fs.o ./Core/lvgl/tests/src/test_cases/test_fs.su ./Core/lvgl/tests/src/test_cases/test_grid.cyclo ./Core/lvgl/tests/src/test_cases/test_grid.d ./Core/lvgl/tests/src/test_cases/test_grid.o ./Core/lvgl/tests/src/test_cases/test_grid.su ./Core/lvgl/tests/src/test_cases/test_group.cyclo ./Core/lvgl/tests/src/test_cases/test_group.d ./Core/lvgl/tests/src/test_cases/test_group.o ./Core/lvgl/tests/src/test_cases/test_group.su ./Core/lvgl/tests/src/test_cases/test_margin_align.cyclo ./Core/lvgl/tests/src/test_cases/test_margin_align.d ./Core/lvgl/tests/src/test_cases/test_margin_align.o ./Core/lvgl/tests/src/test_cases/test_margin_align.su ./Core/lvgl/tests/src/test_cases/test_margin_flex.cyclo ./Core/lvgl/tests/src/test_cases/test_margin_flex.d ./Core/lvgl/tests/src/test_cases/test_margin_flex.o ./Core/lvgl/tests/src/test_cases/test_margin_flex.su ./Core/lvgl/tests/src/test_cases/test_margin_grid.cyclo ./Core/lvgl/tests/src/test_cases/test_margin_grid.d ./Core/lvgl/tests/src/test_cases/test_margin_grid.o ./Core/lvgl/tests/src/test_cases/test_margin_grid.su ./Core/lvgl/tests/src/test_cases/test_math.cyclo ./Core/lvgl/tests/src/test_cases/test_math.d ./Core/lvgl/tests/src/test_cases/test_math.o ./Core/lvgl/tests/src/test_cases/test_math.su ./Core/lvgl/tests/src/test_cases/test_mem.cyclo ./Core/lvgl/tests/src/test_cases/test_mem.d ./Core/lvgl/tests/src/test_cases/test_mem.o ./Core/lvgl/tests/src/test_cases/test_mem.su ./Core/lvgl/tests/src/test_cases/test_observer.cyclo ./Core/lvgl/tests/src/test_cases/test_observer.d ./Core/lvgl/tests/src/test_cases/test_observer.o ./Core/lvgl/tests/src/test_cases/test_observer.su ./Core/lvgl/tests/src/test_cases/test_screen_load.cyclo ./Core/lvgl/tests/src/test_cases/test_screen_load.d ./Core/lvgl/tests/src/test_cases/test_screen_load.o ./Core/lvgl/tests/src/test_cases/test_screen_load.su ./Core/lvgl/tests/src/test_cases/test_snapshot.cyclo ./Core/lvgl/tests/src/test_cases/test_snapshot.d ./Core/lvgl/tests/src/test_cases/test_snapshot.o ./Core/lvgl/tests/src/test_cases/test_snapshot.su ./Core/lvgl/tests/src/test_cases/test_style.cyclo ./Core/lvgl/tests/src/test_cases/test_style.d ./Core/lvgl/tests/src/test_cases/test_style.o ./Core/lvgl/tests/src/test_cases/test_style.su ./Core/lvgl/tests/src/test_cases/test_txt.cyclo ./Core/lvgl/tests/src/test_cases/test_txt.d ./Core/lvgl/tests/src/test_cases/test_txt.o ./Core/lvgl/tests/src/test_cases/test_txt.su

.PHONY: clean-Core-2f-lvgl-2f-tests-2f-src-2f-test_cases

