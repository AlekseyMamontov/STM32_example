################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (11.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/lvgl/tests/src/test_cases/draw/test_clip_corner.c \
../Core/lvgl/tests/src/test_cases/draw/test_draw_blend.c \
../Core/lvgl/tests/src/test_cases/draw/test_draw_label.c \
../Core/lvgl/tests/src/test_cases/draw/test_draw_sw_rotate.c \
../Core/lvgl/tests/src/test_cases/draw/test_draw_vector.c \
../Core/lvgl/tests/src/test_cases/draw/test_image_formats.c \
../Core/lvgl/tests/src/test_cases/draw/test_render_to_argb8888.c \
../Core/lvgl/tests/src/test_cases/draw/test_render_to_rgb565.c \
../Core/lvgl/tests/src/test_cases/draw/test_render_to_rgb888.c \
../Core/lvgl/tests/src/test_cases/draw/test_render_to_xrgb8888.c 

OBJS += \
./Core/lvgl/tests/src/test_cases/draw/test_clip_corner.o \
./Core/lvgl/tests/src/test_cases/draw/test_draw_blend.o \
./Core/lvgl/tests/src/test_cases/draw/test_draw_label.o \
./Core/lvgl/tests/src/test_cases/draw/test_draw_sw_rotate.o \
./Core/lvgl/tests/src/test_cases/draw/test_draw_vector.o \
./Core/lvgl/tests/src/test_cases/draw/test_image_formats.o \
./Core/lvgl/tests/src/test_cases/draw/test_render_to_argb8888.o \
./Core/lvgl/tests/src/test_cases/draw/test_render_to_rgb565.o \
./Core/lvgl/tests/src/test_cases/draw/test_render_to_rgb888.o \
./Core/lvgl/tests/src/test_cases/draw/test_render_to_xrgb8888.o 

C_DEPS += \
./Core/lvgl/tests/src/test_cases/draw/test_clip_corner.d \
./Core/lvgl/tests/src/test_cases/draw/test_draw_blend.d \
./Core/lvgl/tests/src/test_cases/draw/test_draw_label.d \
./Core/lvgl/tests/src/test_cases/draw/test_draw_sw_rotate.d \
./Core/lvgl/tests/src/test_cases/draw/test_draw_vector.d \
./Core/lvgl/tests/src/test_cases/draw/test_image_formats.d \
./Core/lvgl/tests/src/test_cases/draw/test_render_to_argb8888.d \
./Core/lvgl/tests/src/test_cases/draw/test_render_to_rgb565.d \
./Core/lvgl/tests/src/test_cases/draw/test_render_to_rgb888.d \
./Core/lvgl/tests/src/test_cases/draw/test_render_to_xrgb8888.d 


# Each subdirectory must supply rules for building sources it contributes
Core/lvgl/tests/src/test_cases/draw/%.o Core/lvgl/tests/src/test_cases/draw/%.su Core/lvgl/tests/src/test_cases/draw/%.cyclo: ../Core/lvgl/tests/src/test_cases/draw/%.c Core/lvgl/tests/src/test_cases/draw/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m0 -std=gnu11 -DUSE_HAL_DRIVER -DSTM32F072xB -c -I../Core/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F0xx/Include -I../Drivers/CMSIS/Include -Os -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-Core-2f-lvgl-2f-tests-2f-src-2f-test_cases-2f-draw

clean-Core-2f-lvgl-2f-tests-2f-src-2f-test_cases-2f-draw:
	-$(RM) ./Core/lvgl/tests/src/test_cases/draw/test_clip_corner.cyclo ./Core/lvgl/tests/src/test_cases/draw/test_clip_corner.d ./Core/lvgl/tests/src/test_cases/draw/test_clip_corner.o ./Core/lvgl/tests/src/test_cases/draw/test_clip_corner.su ./Core/lvgl/tests/src/test_cases/draw/test_draw_blend.cyclo ./Core/lvgl/tests/src/test_cases/draw/test_draw_blend.d ./Core/lvgl/tests/src/test_cases/draw/test_draw_blend.o ./Core/lvgl/tests/src/test_cases/draw/test_draw_blend.su ./Core/lvgl/tests/src/test_cases/draw/test_draw_label.cyclo ./Core/lvgl/tests/src/test_cases/draw/test_draw_label.d ./Core/lvgl/tests/src/test_cases/draw/test_draw_label.o ./Core/lvgl/tests/src/test_cases/draw/test_draw_label.su ./Core/lvgl/tests/src/test_cases/draw/test_draw_sw_rotate.cyclo ./Core/lvgl/tests/src/test_cases/draw/test_draw_sw_rotate.d ./Core/lvgl/tests/src/test_cases/draw/test_draw_sw_rotate.o ./Core/lvgl/tests/src/test_cases/draw/test_draw_sw_rotate.su ./Core/lvgl/tests/src/test_cases/draw/test_draw_vector.cyclo ./Core/lvgl/tests/src/test_cases/draw/test_draw_vector.d ./Core/lvgl/tests/src/test_cases/draw/test_draw_vector.o ./Core/lvgl/tests/src/test_cases/draw/test_draw_vector.su ./Core/lvgl/tests/src/test_cases/draw/test_image_formats.cyclo ./Core/lvgl/tests/src/test_cases/draw/test_image_formats.d ./Core/lvgl/tests/src/test_cases/draw/test_image_formats.o ./Core/lvgl/tests/src/test_cases/draw/test_image_formats.su ./Core/lvgl/tests/src/test_cases/draw/test_render_to_argb8888.cyclo ./Core/lvgl/tests/src/test_cases/draw/test_render_to_argb8888.d ./Core/lvgl/tests/src/test_cases/draw/test_render_to_argb8888.o ./Core/lvgl/tests/src/test_cases/draw/test_render_to_argb8888.su ./Core/lvgl/tests/src/test_cases/draw/test_render_to_rgb565.cyclo ./Core/lvgl/tests/src/test_cases/draw/test_render_to_rgb565.d ./Core/lvgl/tests/src/test_cases/draw/test_render_to_rgb565.o ./Core/lvgl/tests/src/test_cases/draw/test_render_to_rgb565.su ./Core/lvgl/tests/src/test_cases/draw/test_render_to_rgb888.cyclo ./Core/lvgl/tests/src/test_cases/draw/test_render_to_rgb888.d ./Core/lvgl/tests/src/test_cases/draw/test_render_to_rgb888.o ./Core/lvgl/tests/src/test_cases/draw/test_render_to_rgb888.su ./Core/lvgl/tests/src/test_cases/draw/test_render_to_xrgb8888.cyclo ./Core/lvgl/tests/src/test_cases/draw/test_render_to_xrgb8888.d ./Core/lvgl/tests/src/test_cases/draw/test_render_to_xrgb8888.o ./Core/lvgl/tests/src/test_cases/draw/test_render_to_xrgb8888.su

.PHONY: clean-Core-2f-lvgl-2f-tests-2f-src-2f-test_cases-2f-draw

