################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (11.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/lvgl/tests/src/test_cases/widgets/test_animimg.c \
../Core/lvgl/tests/src/test_cases/widgets/test_arc.c \
../Core/lvgl/tests/src/test_cases/widgets/test_bar.c \
../Core/lvgl/tests/src/test_cases/widgets/test_btn.c \
../Core/lvgl/tests/src/test_cases/widgets/test_btnmatrix.c \
../Core/lvgl/tests/src/test_cases/widgets/test_calendar.c \
../Core/lvgl/tests/src/test_cases/widgets/test_chart.c \
../Core/lvgl/tests/src/test_cases/widgets/test_checkbox.c \
../Core/lvgl/tests/src/test_cases/widgets/test_dropdown.c \
../Core/lvgl/tests/src/test_cases/widgets/test_image.c \
../Core/lvgl/tests/src/test_cases/widgets/test_image_property.c \
../Core/lvgl/tests/src/test_cases/widgets/test_label.c \
../Core/lvgl/tests/src/test_cases/widgets/test_led.c \
../Core/lvgl/tests/src/test_cases/widgets/test_line.c \
../Core/lvgl/tests/src/test_cases/widgets/test_list.c \
../Core/lvgl/tests/src/test_cases/widgets/test_msgbox.c \
../Core/lvgl/tests/src/test_cases/widgets/test_obj_flags.c \
../Core/lvgl/tests/src/test_cases/widgets/test_obj_property.c \
../Core/lvgl/tests/src/test_cases/widgets/test_obj_tree.c \
../Core/lvgl/tests/src/test_cases/widgets/test_objid.c \
../Core/lvgl/tests/src/test_cases/widgets/test_roller.c \
../Core/lvgl/tests/src/test_cases/widgets/test_slider.c \
../Core/lvgl/tests/src/test_cases/widgets/test_span.c \
../Core/lvgl/tests/src/test_cases/widgets/test_spinbox.c \
../Core/lvgl/tests/src/test_cases/widgets/test_spinner.c \
../Core/lvgl/tests/src/test_cases/widgets/test_switch.c \
../Core/lvgl/tests/src/test_cases/widgets/test_table.c \
../Core/lvgl/tests/src/test_cases/widgets/test_tabview.c \
../Core/lvgl/tests/src/test_cases/widgets/test_textarea.c \
../Core/lvgl/tests/src/test_cases/widgets/test_win.c 

OBJS += \
./Core/lvgl/tests/src/test_cases/widgets/test_animimg.o \
./Core/lvgl/tests/src/test_cases/widgets/test_arc.o \
./Core/lvgl/tests/src/test_cases/widgets/test_bar.o \
./Core/lvgl/tests/src/test_cases/widgets/test_btn.o \
./Core/lvgl/tests/src/test_cases/widgets/test_btnmatrix.o \
./Core/lvgl/tests/src/test_cases/widgets/test_calendar.o \
./Core/lvgl/tests/src/test_cases/widgets/test_chart.o \
./Core/lvgl/tests/src/test_cases/widgets/test_checkbox.o \
./Core/lvgl/tests/src/test_cases/widgets/test_dropdown.o \
./Core/lvgl/tests/src/test_cases/widgets/test_image.o \
./Core/lvgl/tests/src/test_cases/widgets/test_image_property.o \
./Core/lvgl/tests/src/test_cases/widgets/test_label.o \
./Core/lvgl/tests/src/test_cases/widgets/test_led.o \
./Core/lvgl/tests/src/test_cases/widgets/test_line.o \
./Core/lvgl/tests/src/test_cases/widgets/test_list.o \
./Core/lvgl/tests/src/test_cases/widgets/test_msgbox.o \
./Core/lvgl/tests/src/test_cases/widgets/test_obj_flags.o \
./Core/lvgl/tests/src/test_cases/widgets/test_obj_property.o \
./Core/lvgl/tests/src/test_cases/widgets/test_obj_tree.o \
./Core/lvgl/tests/src/test_cases/widgets/test_objid.o \
./Core/lvgl/tests/src/test_cases/widgets/test_roller.o \
./Core/lvgl/tests/src/test_cases/widgets/test_slider.o \
./Core/lvgl/tests/src/test_cases/widgets/test_span.o \
./Core/lvgl/tests/src/test_cases/widgets/test_spinbox.o \
./Core/lvgl/tests/src/test_cases/widgets/test_spinner.o \
./Core/lvgl/tests/src/test_cases/widgets/test_switch.o \
./Core/lvgl/tests/src/test_cases/widgets/test_table.o \
./Core/lvgl/tests/src/test_cases/widgets/test_tabview.o \
./Core/lvgl/tests/src/test_cases/widgets/test_textarea.o \
./Core/lvgl/tests/src/test_cases/widgets/test_win.o 

C_DEPS += \
./Core/lvgl/tests/src/test_cases/widgets/test_animimg.d \
./Core/lvgl/tests/src/test_cases/widgets/test_arc.d \
./Core/lvgl/tests/src/test_cases/widgets/test_bar.d \
./Core/lvgl/tests/src/test_cases/widgets/test_btn.d \
./Core/lvgl/tests/src/test_cases/widgets/test_btnmatrix.d \
./Core/lvgl/tests/src/test_cases/widgets/test_calendar.d \
./Core/lvgl/tests/src/test_cases/widgets/test_chart.d \
./Core/lvgl/tests/src/test_cases/widgets/test_checkbox.d \
./Core/lvgl/tests/src/test_cases/widgets/test_dropdown.d \
./Core/lvgl/tests/src/test_cases/widgets/test_image.d \
./Core/lvgl/tests/src/test_cases/widgets/test_image_property.d \
./Core/lvgl/tests/src/test_cases/widgets/test_label.d \
./Core/lvgl/tests/src/test_cases/widgets/test_led.d \
./Core/lvgl/tests/src/test_cases/widgets/test_line.d \
./Core/lvgl/tests/src/test_cases/widgets/test_list.d \
./Core/lvgl/tests/src/test_cases/widgets/test_msgbox.d \
./Core/lvgl/tests/src/test_cases/widgets/test_obj_flags.d \
./Core/lvgl/tests/src/test_cases/widgets/test_obj_property.d \
./Core/lvgl/tests/src/test_cases/widgets/test_obj_tree.d \
./Core/lvgl/tests/src/test_cases/widgets/test_objid.d \
./Core/lvgl/tests/src/test_cases/widgets/test_roller.d \
./Core/lvgl/tests/src/test_cases/widgets/test_slider.d \
./Core/lvgl/tests/src/test_cases/widgets/test_span.d \
./Core/lvgl/tests/src/test_cases/widgets/test_spinbox.d \
./Core/lvgl/tests/src/test_cases/widgets/test_spinner.d \
./Core/lvgl/tests/src/test_cases/widgets/test_switch.d \
./Core/lvgl/tests/src/test_cases/widgets/test_table.d \
./Core/lvgl/tests/src/test_cases/widgets/test_tabview.d \
./Core/lvgl/tests/src/test_cases/widgets/test_textarea.d \
./Core/lvgl/tests/src/test_cases/widgets/test_win.d 


# Each subdirectory must supply rules for building sources it contributes
Core/lvgl/tests/src/test_cases/widgets/%.o Core/lvgl/tests/src/test_cases/widgets/%.su Core/lvgl/tests/src/test_cases/widgets/%.cyclo: ../Core/lvgl/tests/src/test_cases/widgets/%.c Core/lvgl/tests/src/test_cases/widgets/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m0 -std=gnu11 -DUSE_HAL_DRIVER -DSTM32F072xB -c -I../Core/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F0xx/Include -I../Drivers/CMSIS/Include -Os -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-Core-2f-lvgl-2f-tests-2f-src-2f-test_cases-2f-widgets

clean-Core-2f-lvgl-2f-tests-2f-src-2f-test_cases-2f-widgets:
	-$(RM) ./Core/lvgl/tests/src/test_cases/widgets/test_animimg.cyclo ./Core/lvgl/tests/src/test_cases/widgets/test_animimg.d ./Core/lvgl/tests/src/test_cases/widgets/test_animimg.o ./Core/lvgl/tests/src/test_cases/widgets/test_animimg.su ./Core/lvgl/tests/src/test_cases/widgets/test_arc.cyclo ./Core/lvgl/tests/src/test_cases/widgets/test_arc.d ./Core/lvgl/tests/src/test_cases/widgets/test_arc.o ./Core/lvgl/tests/src/test_cases/widgets/test_arc.su ./Core/lvgl/tests/src/test_cases/widgets/test_bar.cyclo ./Core/lvgl/tests/src/test_cases/widgets/test_bar.d ./Core/lvgl/tests/src/test_cases/widgets/test_bar.o ./Core/lvgl/tests/src/test_cases/widgets/test_bar.su ./Core/lvgl/tests/src/test_cases/widgets/test_btn.cyclo ./Core/lvgl/tests/src/test_cases/widgets/test_btn.d ./Core/lvgl/tests/src/test_cases/widgets/test_btn.o ./Core/lvgl/tests/src/test_cases/widgets/test_btn.su ./Core/lvgl/tests/src/test_cases/widgets/test_btnmatrix.cyclo ./Core/lvgl/tests/src/test_cases/widgets/test_btnmatrix.d ./Core/lvgl/tests/src/test_cases/widgets/test_btnmatrix.o ./Core/lvgl/tests/src/test_cases/widgets/test_btnmatrix.su ./Core/lvgl/tests/src/test_cases/widgets/test_calendar.cyclo ./Core/lvgl/tests/src/test_cases/widgets/test_calendar.d ./Core/lvgl/tests/src/test_cases/widgets/test_calendar.o ./Core/lvgl/tests/src/test_cases/widgets/test_calendar.su ./Core/lvgl/tests/src/test_cases/widgets/test_chart.cyclo ./Core/lvgl/tests/src/test_cases/widgets/test_chart.d ./Core/lvgl/tests/src/test_cases/widgets/test_chart.o ./Core/lvgl/tests/src/test_cases/widgets/test_chart.su ./Core/lvgl/tests/src/test_cases/widgets/test_checkbox.cyclo ./Core/lvgl/tests/src/test_cases/widgets/test_checkbox.d ./Core/lvgl/tests/src/test_cases/widgets/test_checkbox.o ./Core/lvgl/tests/src/test_cases/widgets/test_checkbox.su ./Core/lvgl/tests/src/test_cases/widgets/test_dropdown.cyclo ./Core/lvgl/tests/src/test_cases/widgets/test_dropdown.d ./Core/lvgl/tests/src/test_cases/widgets/test_dropdown.o ./Core/lvgl/tests/src/test_cases/widgets/test_dropdown.su ./Core/lvgl/tests/src/test_cases/widgets/test_image.cyclo ./Core/lvgl/tests/src/test_cases/widgets/test_image.d ./Core/lvgl/tests/src/test_cases/widgets/test_image.o ./Core/lvgl/tests/src/test_cases/widgets/test_image.su ./Core/lvgl/tests/src/test_cases/widgets/test_image_property.cyclo ./Core/lvgl/tests/src/test_cases/widgets/test_image_property.d ./Core/lvgl/tests/src/test_cases/widgets/test_image_property.o ./Core/lvgl/tests/src/test_cases/widgets/test_image_property.su ./Core/lvgl/tests/src/test_cases/widgets/test_label.cyclo ./Core/lvgl/tests/src/test_cases/widgets/test_label.d ./Core/lvgl/tests/src/test_cases/widgets/test_label.o ./Core/lvgl/tests/src/test_cases/widgets/test_label.su ./Core/lvgl/tests/src/test_cases/widgets/test_led.cyclo ./Core/lvgl/tests/src/test_cases/widgets/test_led.d ./Core/lvgl/tests/src/test_cases/widgets/test_led.o ./Core/lvgl/tests/src/test_cases/widgets/test_led.su ./Core/lvgl/tests/src/test_cases/widgets/test_line.cyclo ./Core/lvgl/tests/src/test_cases/widgets/test_line.d ./Core/lvgl/tests/src/test_cases/widgets/test_line.o ./Core/lvgl/tests/src/test_cases/widgets/test_line.su ./Core/lvgl/tests/src/test_cases/widgets/test_list.cyclo ./Core/lvgl/tests/src/test_cases/widgets/test_list.d ./Core/lvgl/tests/src/test_cases/widgets/test_list.o ./Core/lvgl/tests/src/test_cases/widgets/test_list.su ./Core/lvgl/tests/src/test_cases/widgets/test_msgbox.cyclo ./Core/lvgl/tests/src/test_cases/widgets/test_msgbox.d ./Core/lvgl/tests/src/test_cases/widgets/test_msgbox.o ./Core/lvgl/tests/src/test_cases/widgets/test_msgbox.su ./Core/lvgl/tests/src/test_cases/widgets/test_obj_flags.cyclo ./Core/lvgl/tests/src/test_cases/widgets/test_obj_flags.d ./Core/lvgl/tests/src/test_cases/widgets/test_obj_flags.o ./Core/lvgl/tests/src/test_cases/widgets/test_obj_flags.su ./Core/lvgl/tests/src/test_cases/widgets/test_obj_property.cyclo ./Core/lvgl/tests/src/test_cases/widgets/test_obj_property.d ./Core/lvgl/tests/src/test_cases/widgets/test_obj_property.o ./Core/lvgl/tests/src/test_cases/widgets/test_obj_property.su ./Core/lvgl/tests/src/test_cases/widgets/test_obj_tree.cyclo ./Core/lvgl/tests/src/test_cases/widgets/test_obj_tree.d ./Core/lvgl/tests/src/test_cases/widgets/test_obj_tree.o ./Core/lvgl/tests/src/test_cases/widgets/test_obj_tree.su ./Core/lvgl/tests/src/test_cases/widgets/test_objid.cyclo ./Core/lvgl/tests/src/test_cases/widgets/test_objid.d ./Core/lvgl/tests/src/test_cases/widgets/test_objid.o ./Core/lvgl/tests/src/test_cases/widgets/test_objid.su ./Core/lvgl/tests/src/test_cases/widgets/test_roller.cyclo ./Core/lvgl/tests/src/test_cases/widgets/test_roller.d ./Core/lvgl/tests/src/test_cases/widgets/test_roller.o ./Core/lvgl/tests/src/test_cases/widgets/test_roller.su ./Core/lvgl/tests/src/test_cases/widgets/test_slider.cyclo ./Core/lvgl/tests/src/test_cases/widgets/test_slider.d ./Core/lvgl/tests/src/test_cases/widgets/test_slider.o ./Core/lvgl/tests/src/test_cases/widgets/test_slider.su ./Core/lvgl/tests/src/test_cases/widgets/test_span.cyclo ./Core/lvgl/tests/src/test_cases/widgets/test_span.d ./Core/lvgl/tests/src/test_cases/widgets/test_span.o ./Core/lvgl/tests/src/test_cases/widgets/test_span.su ./Core/lvgl/tests/src/test_cases/widgets/test_spinbox.cyclo ./Core/lvgl/tests/src/test_cases/widgets/test_spinbox.d ./Core/lvgl/tests/src/test_cases/widgets/test_spinbox.o ./Core/lvgl/tests/src/test_cases/widgets/test_spinbox.su ./Core/lvgl/tests/src/test_cases/widgets/test_spinner.cyclo ./Core/lvgl/tests/src/test_cases/widgets/test_spinner.d ./Core/lvgl/tests/src/test_cases/widgets/test_spinner.o ./Core/lvgl/tests/src/test_cases/widgets/test_spinner.su ./Core/lvgl/tests/src/test_cases/widgets/test_switch.cyclo ./Core/lvgl/tests/src/test_cases/widgets/test_switch.d ./Core/lvgl/tests/src/test_cases/widgets/test_switch.o ./Core/lvgl/tests/src/test_cases/widgets/test_switch.su ./Core/lvgl/tests/src/test_cases/widgets/test_table.cyclo
	-$(RM) ./Core/lvgl/tests/src/test_cases/widgets/test_table.d ./Core/lvgl/tests/src/test_cases/widgets/test_table.o ./Core/lvgl/tests/src/test_cases/widgets/test_table.su ./Core/lvgl/tests/src/test_cases/widgets/test_tabview.cyclo ./Core/lvgl/tests/src/test_cases/widgets/test_tabview.d ./Core/lvgl/tests/src/test_cases/widgets/test_tabview.o ./Core/lvgl/tests/src/test_cases/widgets/test_tabview.su ./Core/lvgl/tests/src/test_cases/widgets/test_textarea.cyclo ./Core/lvgl/tests/src/test_cases/widgets/test_textarea.d ./Core/lvgl/tests/src/test_cases/widgets/test_textarea.o ./Core/lvgl/tests/src/test_cases/widgets/test_textarea.su ./Core/lvgl/tests/src/test_cases/widgets/test_win.cyclo ./Core/lvgl/tests/src/test_cases/widgets/test_win.d ./Core/lvgl/tests/src/test_cases/widgets/test_win.o ./Core/lvgl/tests/src/test_cases/widgets/test_win.su

.PHONY: clean-Core-2f-lvgl-2f-tests-2f-src-2f-test_cases-2f-widgets

