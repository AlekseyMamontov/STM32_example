################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (11.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/lvgl/tests/makefile/test.c 

OBJS += \
./Core/lvgl/tests/makefile/test.o 

C_DEPS += \
./Core/lvgl/tests/makefile/test.d 


# Each subdirectory must supply rules for building sources it contributes
Core/lvgl/tests/makefile/%.o Core/lvgl/tests/makefile/%.su Core/lvgl/tests/makefile/%.cyclo: ../Core/lvgl/tests/makefile/%.c Core/lvgl/tests/makefile/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m0 -std=gnu11 -DUSE_HAL_DRIVER -DSTM32F072xB -c -I../Core/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F0xx/Include -I../Drivers/CMSIS/Include -Os -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-Core-2f-lvgl-2f-tests-2f-makefile

clean-Core-2f-lvgl-2f-tests-2f-makefile:
	-$(RM) ./Core/lvgl/tests/makefile/test.cyclo ./Core/lvgl/tests/makefile/test.d ./Core/lvgl/tests/makefile/test.o ./Core/lvgl/tests/makefile/test.su

.PHONY: clean-Core-2f-lvgl-2f-tests-2f-makefile

