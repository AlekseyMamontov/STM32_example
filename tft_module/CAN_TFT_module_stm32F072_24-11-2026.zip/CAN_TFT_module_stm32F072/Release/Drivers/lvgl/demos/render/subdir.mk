################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (11.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Drivers/lvgl/demos/render/lv_demo_render.c 

OBJS += \
./Drivers/lvgl/demos/render/lv_demo_render.o 

C_DEPS += \
./Drivers/lvgl/demos/render/lv_demo_render.d 


# Each subdirectory must supply rules for building sources it contributes
Drivers/lvgl/demos/render/%.o Drivers/lvgl/demos/render/%.su Drivers/lvgl/demos/render/%.cyclo: ../Drivers/lvgl/demos/render/%.c Drivers/lvgl/demos/render/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m0 -std=gnu11 -DUSE_HAL_DRIVER -DSTM32F072xB -c -I../Core/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F0xx/Include -I../Drivers/CMSIS/Include -Os -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-Drivers-2f-lvgl-2f-demos-2f-render

clean-Drivers-2f-lvgl-2f-demos-2f-render:
	-$(RM) ./Drivers/lvgl/demos/render/lv_demo_render.cyclo ./Drivers/lvgl/demos/render/lv_demo_render.d ./Drivers/lvgl/demos/render/lv_demo_render.o ./Drivers/lvgl/demos/render/lv_demo_render.su

.PHONY: clean-Drivers-2f-lvgl-2f-demos-2f-render

