################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (11.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Drivers/lvgl/demos/transform/lv_demo_transform.c 

OBJS += \
./Drivers/lvgl/demos/transform/lv_demo_transform.o 

C_DEPS += \
./Drivers/lvgl/demos/transform/lv_demo_transform.d 


# Each subdirectory must supply rules for building sources it contributes
Drivers/lvgl/demos/transform/%.o Drivers/lvgl/demos/transform/%.su Drivers/lvgl/demos/transform/%.cyclo: ../Drivers/lvgl/demos/transform/%.c Drivers/lvgl/demos/transform/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m0 -std=gnu11 -DUSE_HAL_DRIVER -DSTM32F072xB -c -I../Core/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F0xx/Include -I../Drivers/CMSIS/Include -Os -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-Drivers-2f-lvgl-2f-demos-2f-transform

clean-Drivers-2f-lvgl-2f-demos-2f-transform:
	-$(RM) ./Drivers/lvgl/demos/transform/lv_demo_transform.cyclo ./Drivers/lvgl/demos/transform/lv_demo_transform.d ./Drivers/lvgl/demos/transform/lv_demo_transform.o ./Drivers/lvgl/demos/transform/lv_demo_transform.su

.PHONY: clean-Drivers-2f-lvgl-2f-demos-2f-transform

