################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (11.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Drivers/lvgl/examples/widgets/arc/lv_example_arc_1.c \
../Drivers/lvgl/examples/widgets/arc/lv_example_arc_2.c 

OBJS += \
./Drivers/lvgl/examples/widgets/arc/lv_example_arc_1.o \
./Drivers/lvgl/examples/widgets/arc/lv_example_arc_2.o 

C_DEPS += \
./Drivers/lvgl/examples/widgets/arc/lv_example_arc_1.d \
./Drivers/lvgl/examples/widgets/arc/lv_example_arc_2.d 


# Each subdirectory must supply rules for building sources it contributes
Drivers/lvgl/examples/widgets/arc/%.o Drivers/lvgl/examples/widgets/arc/%.su Drivers/lvgl/examples/widgets/arc/%.cyclo: ../Drivers/lvgl/examples/widgets/arc/%.c Drivers/lvgl/examples/widgets/arc/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m0 -std=gnu11 -DUSE_HAL_DRIVER -DSTM32F072xB -c -I../Core/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F0xx/Include -I../Drivers/CMSIS/Include -Os -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-Drivers-2f-lvgl-2f-examples-2f-widgets-2f-arc

clean-Drivers-2f-lvgl-2f-examples-2f-widgets-2f-arc:
	-$(RM) ./Drivers/lvgl/examples/widgets/arc/lv_example_arc_1.cyclo ./Drivers/lvgl/examples/widgets/arc/lv_example_arc_1.d ./Drivers/lvgl/examples/widgets/arc/lv_example_arc_1.o ./Drivers/lvgl/examples/widgets/arc/lv_example_arc_1.su ./Drivers/lvgl/examples/widgets/arc/lv_example_arc_2.cyclo ./Drivers/lvgl/examples/widgets/arc/lv_example_arc_2.d ./Drivers/lvgl/examples/widgets/arc/lv_example_arc_2.o ./Drivers/lvgl/examples/widgets/arc/lv_example_arc_2.su

.PHONY: clean-Drivers-2f-lvgl-2f-examples-2f-widgets-2f-arc

