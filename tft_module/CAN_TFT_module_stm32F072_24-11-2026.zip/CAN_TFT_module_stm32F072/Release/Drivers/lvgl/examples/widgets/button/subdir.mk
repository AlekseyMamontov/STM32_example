################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (11.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Drivers/lvgl/examples/widgets/button/lv_example_button_1.c \
../Drivers/lvgl/examples/widgets/button/lv_example_button_2.c \
../Drivers/lvgl/examples/widgets/button/lv_example_button_3.c 

OBJS += \
./Drivers/lvgl/examples/widgets/button/lv_example_button_1.o \
./Drivers/lvgl/examples/widgets/button/lv_example_button_2.o \
./Drivers/lvgl/examples/widgets/button/lv_example_button_3.o 

C_DEPS += \
./Drivers/lvgl/examples/widgets/button/lv_example_button_1.d \
./Drivers/lvgl/examples/widgets/button/lv_example_button_2.d \
./Drivers/lvgl/examples/widgets/button/lv_example_button_3.d 


# Each subdirectory must supply rules for building sources it contributes
Drivers/lvgl/examples/widgets/button/%.o Drivers/lvgl/examples/widgets/button/%.su Drivers/lvgl/examples/widgets/button/%.cyclo: ../Drivers/lvgl/examples/widgets/button/%.c Drivers/lvgl/examples/widgets/button/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m0 -std=gnu11 -DUSE_HAL_DRIVER -DSTM32F072xB -c -I../Core/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F0xx/Include -I../Drivers/CMSIS/Include -Os -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-Drivers-2f-lvgl-2f-examples-2f-widgets-2f-button

clean-Drivers-2f-lvgl-2f-examples-2f-widgets-2f-button:
	-$(RM) ./Drivers/lvgl/examples/widgets/button/lv_example_button_1.cyclo ./Drivers/lvgl/examples/widgets/button/lv_example_button_1.d ./Drivers/lvgl/examples/widgets/button/lv_example_button_1.o ./Drivers/lvgl/examples/widgets/button/lv_example_button_1.su ./Drivers/lvgl/examples/widgets/button/lv_example_button_2.cyclo ./Drivers/lvgl/examples/widgets/button/lv_example_button_2.d ./Drivers/lvgl/examples/widgets/button/lv_example_button_2.o ./Drivers/lvgl/examples/widgets/button/lv_example_button_2.su ./Drivers/lvgl/examples/widgets/button/lv_example_button_3.cyclo ./Drivers/lvgl/examples/widgets/button/lv_example_button_3.d ./Drivers/lvgl/examples/widgets/button/lv_example_button_3.o ./Drivers/lvgl/examples/widgets/button/lv_example_button_3.su

.PHONY: clean-Drivers-2f-lvgl-2f-examples-2f-widgets-2f-button

