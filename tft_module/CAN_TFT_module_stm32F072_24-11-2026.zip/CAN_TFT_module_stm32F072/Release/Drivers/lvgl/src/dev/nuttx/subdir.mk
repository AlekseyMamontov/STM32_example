################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (11.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Drivers/lvgl/src/dev/nuttx/lv_nuttx_entry.c \
../Drivers/lvgl/src/dev/nuttx/lv_nuttx_fbdev.c \
../Drivers/lvgl/src/dev/nuttx/lv_nuttx_lcd.c \
../Drivers/lvgl/src/dev/nuttx/lv_nuttx_libuv.c \
../Drivers/lvgl/src/dev/nuttx/lv_nuttx_touchscreen.c 

OBJS += \
./Drivers/lvgl/src/dev/nuttx/lv_nuttx_entry.o \
./Drivers/lvgl/src/dev/nuttx/lv_nuttx_fbdev.o \
./Drivers/lvgl/src/dev/nuttx/lv_nuttx_lcd.o \
./Drivers/lvgl/src/dev/nuttx/lv_nuttx_libuv.o \
./Drivers/lvgl/src/dev/nuttx/lv_nuttx_touchscreen.o 

C_DEPS += \
./Drivers/lvgl/src/dev/nuttx/lv_nuttx_entry.d \
./Drivers/lvgl/src/dev/nuttx/lv_nuttx_fbdev.d \
./Drivers/lvgl/src/dev/nuttx/lv_nuttx_lcd.d \
./Drivers/lvgl/src/dev/nuttx/lv_nuttx_libuv.d \
./Drivers/lvgl/src/dev/nuttx/lv_nuttx_touchscreen.d 


# Each subdirectory must supply rules for building sources it contributes
Drivers/lvgl/src/dev/nuttx/%.o Drivers/lvgl/src/dev/nuttx/%.su Drivers/lvgl/src/dev/nuttx/%.cyclo: ../Drivers/lvgl/src/dev/nuttx/%.c Drivers/lvgl/src/dev/nuttx/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m0 -std=gnu11 -DUSE_HAL_DRIVER -DSTM32F072xB -c -I../Core/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F0xx/Include -I../Drivers/CMSIS/Include -Os -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-Drivers-2f-lvgl-2f-src-2f-dev-2f-nuttx

clean-Drivers-2f-lvgl-2f-src-2f-dev-2f-nuttx:
	-$(RM) ./Drivers/lvgl/src/dev/nuttx/lv_nuttx_entry.cyclo ./Drivers/lvgl/src/dev/nuttx/lv_nuttx_entry.d ./Drivers/lvgl/src/dev/nuttx/lv_nuttx_entry.o ./Drivers/lvgl/src/dev/nuttx/lv_nuttx_entry.su ./Drivers/lvgl/src/dev/nuttx/lv_nuttx_fbdev.cyclo ./Drivers/lvgl/src/dev/nuttx/lv_nuttx_fbdev.d ./Drivers/lvgl/src/dev/nuttx/lv_nuttx_fbdev.o ./Drivers/lvgl/src/dev/nuttx/lv_nuttx_fbdev.su ./Drivers/lvgl/src/dev/nuttx/lv_nuttx_lcd.cyclo ./Drivers/lvgl/src/dev/nuttx/lv_nuttx_lcd.d ./Drivers/lvgl/src/dev/nuttx/lv_nuttx_lcd.o ./Drivers/lvgl/src/dev/nuttx/lv_nuttx_lcd.su ./Drivers/lvgl/src/dev/nuttx/lv_nuttx_libuv.cyclo ./Drivers/lvgl/src/dev/nuttx/lv_nuttx_libuv.d ./Drivers/lvgl/src/dev/nuttx/lv_nuttx_libuv.o ./Drivers/lvgl/src/dev/nuttx/lv_nuttx_libuv.su ./Drivers/lvgl/src/dev/nuttx/lv_nuttx_touchscreen.cyclo ./Drivers/lvgl/src/dev/nuttx/lv_nuttx_touchscreen.d ./Drivers/lvgl/src/dev/nuttx/lv_nuttx_touchscreen.o ./Drivers/lvgl/src/dev/nuttx/lv_nuttx_touchscreen.su

.PHONY: clean-Drivers-2f-lvgl-2f-src-2f-dev-2f-nuttx

