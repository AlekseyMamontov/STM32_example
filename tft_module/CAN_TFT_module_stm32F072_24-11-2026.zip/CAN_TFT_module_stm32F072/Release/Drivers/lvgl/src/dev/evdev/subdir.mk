################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (11.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Drivers/lvgl/src/dev/evdev/lv_evdev.c 

OBJS += \
./Drivers/lvgl/src/dev/evdev/lv_evdev.o 

C_DEPS += \
./Drivers/lvgl/src/dev/evdev/lv_evdev.d 


# Each subdirectory must supply rules for building sources it contributes
Drivers/lvgl/src/dev/evdev/%.o Drivers/lvgl/src/dev/evdev/%.su Drivers/lvgl/src/dev/evdev/%.cyclo: ../Drivers/lvgl/src/dev/evdev/%.c Drivers/lvgl/src/dev/evdev/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m0 -std=gnu11 -DUSE_HAL_DRIVER -DSTM32F072xB -c -I../Core/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F0xx/Include -I../Drivers/CMSIS/Include -Os -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-Drivers-2f-lvgl-2f-src-2f-dev-2f-evdev

clean-Drivers-2f-lvgl-2f-src-2f-dev-2f-evdev:
	-$(RM) ./Drivers/lvgl/src/dev/evdev/lv_evdev.cyclo ./Drivers/lvgl/src/dev/evdev/lv_evdev.d ./Drivers/lvgl/src/dev/evdev/lv_evdev.o ./Drivers/lvgl/src/dev/evdev/lv_evdev.su

.PHONY: clean-Drivers-2f-lvgl-2f-src-2f-dev-2f-evdev

