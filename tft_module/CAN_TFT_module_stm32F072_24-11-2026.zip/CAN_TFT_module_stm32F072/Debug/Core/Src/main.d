Core/Src/main.o: ../Core/Src/main.c ../Core/Inc/main.h \
 ../Drivers/CMSIS/Device/ST/STM32F0xx/Include/stm32f0xx.h \
 ../Drivers/CMSIS/Device/ST/STM32F0xx/Include/stm32f072xb.h \
 ../Drivers/CMSIS/Include/core_cm0.h \
 ../Drivers/CMSIS/Include/cmsis_version.h \
 ../Drivers/CMSIS/Include/cmsis_compiler.h \
 ../Drivers/CMSIS/Include/cmsis_gcc.h \
 ../Drivers/CMSIS/Device/ST/STM32F0xx/Include/system_stm32f0xx.h \
 ../Core/Inc/CANOpen.h ../Core/Inc/tft_panel_8bit.h \
 ../Core/Inc/tft_init_display.h ../Core/Inc/fonts.h \
 ../Core/Inc/tft_screens.h ../Core/Inc/tft_widgets.h
../Core/Inc/main.h:
../Drivers/CMSIS/Device/ST/STM32F0xx/Include/stm32f0xx.h:
../Drivers/CMSIS/Device/ST/STM32F0xx/Include/stm32f072xb.h:
../Drivers/CMSIS/Include/core_cm0.h:
../Drivers/CMSIS/Include/cmsis_version.h:
../Drivers/CMSIS/Include/cmsis_compiler.h:
../Drivers/CMSIS/Include/cmsis_gcc.h:
../Drivers/CMSIS/Device/ST/STM32F0xx/Include/system_stm32f0xx.h:
../Core/Inc/CANOpen.h:
../Core/Inc/tft_panel_8bit.h:
../Core/Inc/tft_init_display.h:
../Core/Inc/fonts.h:
../Core/Inc/tft_screens.h:
../Core/Inc/tft_widgets.h:
