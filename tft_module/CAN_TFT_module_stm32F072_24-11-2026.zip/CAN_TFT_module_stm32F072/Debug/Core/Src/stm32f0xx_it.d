Core/Src/stm32f0xx_it.o: ../Core/Src/stm32f0xx_it.c \
 ../Core/Inc/stm32f0xx_it.h
../Core/Inc/stm32f0xx_it.h:
