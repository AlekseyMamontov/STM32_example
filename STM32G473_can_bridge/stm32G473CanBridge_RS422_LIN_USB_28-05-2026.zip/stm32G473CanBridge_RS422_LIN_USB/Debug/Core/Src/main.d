Core/Src/main.o: ../Core/Src/main.c \
 ../Drivers/CMSIS/Device/ST/STM32G4xx/Include/stm32g4xx.h \
 ../Drivers/CMSIS/Device/ST/STM32G4xx/Include/stm32g473xx.h \
 ../Drivers/CMSIS/Include/core_cm4.h \
 ../Drivers/CMSIS/Include/cmsis_version.h \
 ../Drivers/CMSIS/Include/cmsis_compiler.h \
 ../Drivers/CMSIS/Include/cmsis_gcc.h \
 ../Drivers/CMSIS/Include/mpu_armv7.h \
 ../Drivers/CMSIS/Device/ST/STM32G4xx/Include/system_stm32g4xx.h \
 ../Core/Inc/INIT_STM32G473_GPIO.h ../Core/Inc/CANFD_STM32G473.h \
 ../Core/Inc/main.h
../Drivers/CMSIS/Device/ST/STM32G4xx/Include/stm32g4xx.h:
../Drivers/CMSIS/Device/ST/STM32G4xx/Include/stm32g473xx.h:
../Drivers/CMSIS/Include/core_cm4.h:
../Drivers/CMSIS/Include/cmsis_version.h:
../Drivers/CMSIS/Include/cmsis_compiler.h:
../Drivers/CMSIS/Include/cmsis_gcc.h:
../Drivers/CMSIS/Include/mpu_armv7.h:
../Drivers/CMSIS/Device/ST/STM32G4xx/Include/system_stm32g4xx.h:
../Core/Inc/INIT_STM32G473_GPIO.h:
../Core/Inc/CANFD_STM32G473.h:
../Core/Inc/main.h:
