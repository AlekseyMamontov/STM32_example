.. zephyr:board:: mult_canbridge

Overview
********

MultBridge is a six-channel isolated CAN FD bridge built from three STM32G473
MCUs and one ESP32-S3. Every MCU is a separate Zephyr target (board variant),
the MCUs and the ESP32-S3 are tied together by a classic-CAN internal bus.

Board targets
*************

======================================  ===========================================
Target                                  Role
======================================  ===========================================
``mult_canbridge/stm32g473xx/mcu1``     2 external FDCAN, internal bus, USB (PA11/PA12)
``mult_canbridge/stm32g473xx/mcu2``     2 external FDCAN, internal bus
``mult_canbridge/stm32g473xx/mcu3``     2 external FDCAN, internal bus, SPI slave to ESP32-S3
``mult_canbridge/esp32s3/procpu``       internal bus (TWAI), SPI master to MCU3, USB-Serial/JTAG, Wi-Fi/BLE
======================================  ===========================================

Peripheral mapping
******************

MCU1: FDCAN1 PB8/PB9, FDCAN2 PB12/PB13, FDCAN3 (internal) PA8/PA15, USB PA11/PA12, LED PA3.

MCU2, MCU3: FDCAN1 PA11/PA12, FDCAN3 PA8/PA15, FDCAN2 (internal) PB5/PB6, LED PA3.

MCU3 <-> ESP32-S3 SPI: CS PA4/IO14, SCK PA5/IO12, MISO PA6/IO13, MOSI PA7/IO11.

ESP32-S3: TWAI RX IO47, TX IO48; USB IO19/IO20; UART0.

Programming and Debugging
*************************

Each STM32 has its own SWD header (RST, SWO, SWCLK, SWDIO, 3V3, GND)::

   west build -b mult_canbridge/stm32g473xx/mcu1 samples/basic/blinky
   west flash --dev-id <ST-LINK serial>

ESP32-S3 is flashed through the Type-C port::

   west build -b mult_canbridge/esp32s3/procpu samples/basic/blinky
   west flash
